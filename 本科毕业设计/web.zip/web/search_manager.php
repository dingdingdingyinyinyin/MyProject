<?php
	header("content-type:text/html;charset=utf8");
	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	mysql_query('set names utf8');
	$key=$_POST['key'];

	$sql="SELECT * FROM manager WHERE username = '$key' or mobilePhone = '$key' or Email = '$key'";
	$result=mysql_query($sql);
	$rs=mysql_num_rows($result);
	$dataList=array();
	while($row=mysql_fetch_assoc($result))
	{
		//将结果集 result 的内容选择需要的整理并放在 $dataList 中
		$dataList[]=array("id"=>$row['id'],"username"=>$row['username'],"password"=>$row['password'],"mobilePhone"=>$row['mobilePhone'],"registerTime"=>$row['registerTime'],"Email"=>$row['Email']);
	}
	echo json_encode($dataList);
?>
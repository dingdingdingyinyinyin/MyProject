<?php

	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	//mysql_select_db('rfid') or die('数据库选择失败');
	mysql_query('set names utf8');
	$rs=mysql_query('SELECT * FROM package_entrucking where State=0');
	$dataList = array();
	while($row=mysql_fetch_assoc($rs))
	{
		//将结果集 rs 的内容选择需要的整理并放在 $dataList 中
		$dataList[]=array("id"=>$row['id'],"RFID"=>$row['RFID'],"DesAddress"=>$row['DesAddress'],
						"StartAddress"=>$row['StartAddress'],"Num"=>$row['Num'],
						"RecipientTime"=>$row['RecipientTime'],"Driver"=>$row['Driver'],"DriverPhone"=>$row['DriverPhone']);
	}

	//返回前端数据
	//$callback = $_GET['jsoncallback'];//关键是这个。若是在ajax()内设置了jsonp:"jsoncallback",那么填写jsoncallback，本王上面设置了，没有设置则直接填写callback（默认值）
   // exit($callback."(".json_encode($dataList).")");
	echo json_encode( $dataList );
?>



<?php

	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	//mysql_select_db('rfid') or die('数据库选择失败');
	mysql_query('set names utf8');
	$dataList = array();
	$num_Recipient=array(0,0,0,0,0,0,0);//今天0，昨天1，前天2，大前天3……
	$num_ArriveTime=array(0,0,0,0,0,0,0);//今天0，昨天1，前天2，大前天3……
	$num_Recipient_car=array(0,0,0,0,0,0,0);//今天0，昨天1，前天2，大前天3……
	$num_ArriveTime_car=array(0,0,0,0,0,0,0);//今天0，昨天1，前天2，大前天3……
	//获取今天00:00,24:00
	$todaystart = strtotime(date('Y-m-d'.'00:00:00',time()));
	$todayend = strtotime(date('Y-m-d'.'00:00:00',time()+3600*24));	 
	$todaystart_1 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*1));
	$todayend_1 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*0));	 
	$todaystart_2 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*2));
	$todayend_2 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*1));	 
	$todaystart_3 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*3));
	$todayend_3 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*2));	 
	$todaystart_4 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*4));
	$todayend_4 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*3));	 
	$todaystart_5 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*5));
	$todayend_5 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*4));	 
	$todaystart_6 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*6));
	$todayend_6 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*5));	 
	$todaystart_7 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*7));
	$todayend_7 = strtotime(date('Y-m-d'.'00:00:00',time()-3600*24*6));	 

	$today=date('Y-m-d',time());
	$date=array(date('Y-m-d',time()),date('Y-m-d',time()-3600*24*1),date('Y-m-d',time()-3600*24*2),date('Y-m-d',time()-3600*24*3),date('Y-m-d',time()-3600*24*4),date('Y-m-d',time()-3600*24*5),date('Y-m-d',time()-3600*24*6));

	$rs=mysql_query('SELECT * FROM package_information');
	while($row=mysql_fetch_assoc($rs))
	{	
		
		//今天起，7天内的揽件数
		$now=$row['RecipientTime'];
		$now=strtotime($now);		
		if($now>=$todaystart&&$now<=$todayend)
		{
			$num_Recipient[0]++;
		}
		else if($now>=$todaystart_1&&$now<=$todayend_1)
		{
			$num_Recipient[1]++;
		}
		else if($now>=$todaystart_2&&$now<=$todayend_2)
		{
			$num_Recipient[2]++;
		}
		else if($now>=$todaystart_3&&$now<=$todayend_3)
		{
			$num_Recipient[3]++;
		}
		else if($now>=$todaystart_4&&$now<=$todayend_4)
		{
			$num_Recipient[4]++;
		}
		else if($now>=$todaystart_5&&$now<=$todayend_5)
		{
			$num_Recipient[5]++;
		}
		else if($now>=$todaystart_6&&$now<=$todayend_6)
		{
			$num_Recipient[6]++;
		}
		//今天起，7天内的派送完成数
		$now=$row['ArriveTime'];
		$now=strtotime($now);
		if($now>=$todaystart&&$now<=$todayend)
		{
			$num_ArriveTime[0]++;
		}
		else if($now>=$todaystart_1&&$now<=$todayend_1)
		{
			$num_ArriveTime[1]++;
		}
		else if($now>=$todaystart_2&&$now<=$todayend_2)
		{
			$num_ArriveTime[2]++;
		}
		else if($now>=$todaystart_3&&$now<=$todayend_3)
		{
			$num_ArriveTime[3]++;
		}
		else if($now>=$todaystart_4&&$now<=$todayend_4)
		{
			$num_ArriveTime[4]++;
		}
		else if($now>=$todaystart_5&&$now<=$todayend_5)
		{
			$num_ArriveTime[5]++;
		}
		else if($now>=$todaystart_6&&$now<=$todayend_6)
		{
			$num_ArriveTime[6]++;
		}
		//echo $now." ".$todaystart." ".$todayend."\n";
	}

	$rs=mysql_query('SELECT * FROM package_entrucking');
	while($row=mysql_fetch_assoc($rs))
	{
		//今天起，7天内的车辆出发数
		$now=$row['RecipientTime'];
		$now=strtotime($now);		
		if($now>=$todaystart&&$now<=$todayend)
		{
			$num_Recipient_car[0]++;
		}
		else if($now>=$todaystart_1&&$now<=$todayend_1)
		{
			$num_Recipient_car[1]++;
		}
		else if($now>=$todaystart_2&&$now<=$todayend_2)
		{
			$num_Recipient_car[2]++;
		}
		else if($now>=$todaystart_3&&$now<=$todayend_3)
		{
			$num_Recipient_car[3]++;
		}
		else if($now>=$todaystart_4&&$now<=$todayend_4)
		{
			$num_Recipient_car[4]++;
		}
		else if($now>=$todaystart_5&&$now<=$todayend_5)
		{
			$num_Recipient_car[5]++;
		}
		else if($now>=$todaystart_6&&$now<=$todayend_6)
		{
			$num_Recipient_car[6]++;
		}
		//今天起，7天内的车辆到达数
		$now=$row['ArriveTime'];
		$now=strtotime($now);
		if($now>=$todaystart&&$now<=$todayend)
		{
			$num_ArriveTime_car[0]++;
		}
		else if($now>=$todaystart_1&&$now<=$todayend_1)
		{
			$num_ArriveTime_car[1]++;
		}
		else if($now>=$todaystart_2&&$now<=$todayend_2)
		{
			$num_ArriveTime_car[2]++;
		}
		else if($now>=$todaystart_3&&$now<=$todayend_3)
		{
			$num_ArriveTime_car[3]++;
		}
		else if($now>=$todaystart_4&&$now<=$todayend_4)
		{
			$num_ArriveTime_car[4]++;
		}
		else if($now>=$todaystart_5&&$now<=$todayend_5)
		{
			$num_ArriveTime_car[5]++;
		}
		else if($now>=$todaystart_6&&$now<=$todayend_6)
		{
			$num_ArriveTime_car[6]++;
		}
		//echo $now." ".$todaystart." ".$todayend."\n";
	}
	//($num_Recipient);
	//var_dump($num_ArriveTime);
	//var_dump($num_Recipient_car);
	//var_dump($num_ArriveTime_car);
	$dataList[]=array('date'=>$date,'num_Recipient'=>$num_Recipient,'num_ArriveTime'=>$num_ArriveTime,'num_Recipient_car'=>$num_Recipient_car,'num_ArriveTime_car'=>$num_ArriveTime_car);
	echo json_encode( $dataList );

?>
<?php
	header("content-type:text/html;charset=utf8");
	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	//mysql_select_db('rfid') or die('数据库选择失败');
	mysql_query('set names utf8');

	$id=$_POST['id'];
	if($id!=null){
		mysql_query("delete from package_information where id=$id");
		echo 'OK';
	}
	else{
		echo "NO";
	}
?>
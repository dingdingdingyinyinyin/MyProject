<?php
if(isset($_POST['register_btn'])){
	include('./conn.php');
	//获取提交的信息
	$username=$_POST['username'];
	$password=$_POST['password'];
	$password_again=$_POST['password_again'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	if(isset($_POST['check'])){
		$check=$_POST['check'];
		//验证数据的有效性
		if( mb_strlen( $username,'utf-8' )<2 ){
			echo '<script>alert("用户名不能少于2个字");
					</script>';	
			exit;
		}
		if( strlen ( $password ) <6 ){
			echo '<script>alert("密码不能少于6位数");
					</script>';	
			exit;
		}
		if( $password != $password_again ){
			echo '<script>alert("两次输入的密码不一致");
					</script>';	
			exit;
		}
		if(!preg_match("/^1[34578]{1}\d{9}$/",$phone)){  
			echo '<script>alert("手机号码错误");
					</script>';	
			exit; 
		}
		//构造sql语句连接数据库

		$password = md5( $password );
		//echo $password;
		$sql = "insert into manager(username,password,Email,mobilePhone) 
				values( '$username','$password','$email','$phone')";
		$r = mysqli_query( $conn,$sql );
		//返回执行结果
		
		if( $r ){
			echo '<script>alert("注册成功，请重新登录");
					location.href="./login.html";</script>';	
		}else{
			echo '<script>alert("注册失败");</script>';
		}
	}
	else{
		echo '<script>alert("注册失败，请重新注册");
			location.href="./login.html";</script>';
	}
}
?>
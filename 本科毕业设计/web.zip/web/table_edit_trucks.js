function getData() {
    var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
    //获取列表
    $.ajax({
        type: "POST",
        url: "trucks_information.php",
        dataType: "json",
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
        success: function(data) {
            if ($.isEmptyObject(data)) {
                $loading.html("当前没有数据");
            } else {
                var str = "";
				var flag=0;
                $.each(data,function(index, item) {
					flag++;
                    str += '<tr><td align="center">' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" + flag + 
						"</td><td style='padding:8px 8px'>" + item.RFID + 
						"</td><td style='padding:8px 8px'>" + item.plateNumber + 
						"</td><td style='padding:8px 8px'>" + item.models + 
						"</td><td style='padding:8px 8px'>" + item.limitedNumber + 
						"</td><td style='padding:8px 8px'>" + item.volumeOfCargo + 
						"</td><td style='padding:8px 8px'>" + item.personInCharge + 
						"</td><td style='padding:8px 8px'>" + item.phone + 
						"</td><td style='padding:8px 8px'>" + item.remarks +
						'<td>' +
							'<button class="btn btn-xs btn-success" onclick="modify(this);"style="width:50%;height:100%;float:left" >' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-primary" onclick="del(this);" style="width:50%;height:100%;">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                });
				$tbody.html(str);	
                $loading.html("");
                page = new Page(8, 'sample-table-1', 'sample-tbody-1');
            }
        }
    })
}

//add功能
function addList() {
    var RFID = document.getElementById('RFID-m').value;
	var plateNumber = document.getElementById('plateNumber-m').value;
    var models = document.getElementById('models-m').value;
    var limitedNumber = document.getElementById('limitedNumber-m').value;
	var volumeOfCargo = document.getElementById('volumeOfCargo-m').value;
    var personInCharge = document.getElementById('personInCharge-m').value;
	var phone = document.getElementById('phone-m').value;
    var remarks = document.getElementById('remarks-m').value;
    if (window.confirm("你确定要增加吗？")) {
        $.ajax({
            type: "POST",
            url: "add_trucks.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFID: RFID,
				plateNumber:plateNumber,
                models: models,
                limitedNumber: limitedNumber,
                volumeOfCargo: volumeOfCargo,
				personInCharge: personInCharge,
                phone: phone,
                remarks: remarks
            },
            success: function(data) {
					//alert(data);
                if (data.trim() == "OK") {
                    alert("添加成功");
                    getData();
                } else {
                    alert("添加失败");
                }
            }
        })
			document.getElementById("form-m").reset();
    }

}

//del单点功能
function del(obj) {
    if (window.confirm("你确定要删除吗？")) {
        var temp = $(obj).parent().parent().find("td:eq(3)").text();
        // 发送至php,进行数据库的更改		
        $.ajax({
            type: "POST",
            url: "del_trucks.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
               number: temp
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//全选
function checkAll(c) {
    var status = c.checked;
    var oItems = document.getElementsByName('item');
    for (var i = 0; i < oItems.length; i++) {
        oItems[i].checked = status;
    }
}
//delAll功能
function delAll() {
    if (window.confirm("你确定要删除吗？")) {
        var temp = "";
        var str = "";
        var items = document.getElementsByName("item");
        for (var j = 1; j < items.length; j++) {
            if (items[j].checked) {
                temp = $(items[j]).parent().parent().parent().find("td:eq(3)").text();
					str += "\""+temp +"\""+ ',';
            }
        }
		str = str.substring(0,str.length-1);
        str = '(' + str + ')';
        $.ajax({
            type: "POST",
            url: "delAll_trucks.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                numberAll: str
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//modify功能
function modify(obj) {
    var id = document.getElementById('id-m');
    var RFID = document.getElementById('RFID-m');
	var plateNumber = document.getElementById('plateNumber-m');
	plateNumber.setAttribute("readonly","readonly");
	var models = document.getElementById('models-m');
    var limitedNumber = document.getElementById('limitedNumber-m');
    var volumeOfCargo = document.getElementById('volumeOfCargo-m');
	var personInCharge = document.getElementById('personInCharge-m');
    var phone = document.getElementById('phone-m');
    var remarks = document.getElementById('remarks-m');
	
    var oTr = obj.parentNode.parentNode;
    var aTd = oTr.getElementsByTagName('td');
    rowIndex = obj.parentNode.parentNode.rowIndex;
	//for(var i=1;i<14;i++)
	//	alert(aTd[i].innerHTML);
    id.value = aTd[1].innerHTML;
    RFID.value = aTd[2].innerHTML;
	plateNumber.value = aTd[3].innerHTML;
	models.value = aTd[4].innerHTML;
	limitedNumber.value = aTd[5].innerHTML;
    volumeOfCargo.value= aTd[6].innerHTML;
	personInCharge.value = aTd[7].innerHTML;
	phone.value= aTd[8].innerHTML;
	remarks.value = aTd[9].innerHTML;
}
//update功能
function update() {
	var id = document.getElementById('id-m');
    var RFID = document.getElementById('RFID-m');
	var plateNumber = document.getElementById('plateNumber-m');
	var models = document.getElementById('models-m');
    var limitedNumber = document.getElementById('limitedNumber-m');
    var volumeOfCargo = document.getElementById('volumeOfCargo-m');
	var personInCharge = document.getElementById('personInCharge-m');
    var phone = document.getElementById('phone-m');
    var remarks = document.getElementById('remarks-m');

    if (window.confirm("你确定要修改吗？")) {
        $.ajax({
            type: "POST",
            url: "update_trucks.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFID: RFID.value,
				plateNumber:plateNumber.value,
				models: models.value,
                limitedNumber: limitedNumber.value,
                volumeOfCargo: volumeOfCargo.value,
                personInCharge: personInCharge.value,
				phone: phone.value,
                remarks: remarks.value
            },

            success: function(data) {
                if (data.trim() == "OK") {
                    alert("更新成功");
                    getData();
                } else {
                    alert("更新失败");
                }
            }

        })
		document.getElementById("form-m").reset();
		plateNumber.removeAttribute("readonly");
    }
}

function search() {
	var temp = document.getElementById('input-search').value;
	var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
	//alert(temp);
	$.ajax({
		type:"POST",
		url:"search_trucks.php",
		contentType: "application/x-www-form-urlencoded;charset=utf-8",
        dataType: "json",
        data: {
			key:temp
		},
		
		beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
		success: function(data) {
			//alert(data);
			if ($.isEmptyObject(data)) {
				$loading.html("没有相关数据");
			} 
			else {
                var str = "";
				var flag=0;
                $.each(data,function(index, item) {
					flag++;
                     str += '<tr><td align="center">' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" + flag + 
						"</td><td style='padding:8px 8px'>" + item.RFID + 
						"</td><td style='padding:8px 8px'>" + item.plateNumber + 
						"</td><td style='padding:8px 8px'>" + item.models + 
						"</td><td style='padding:8px 8px'>" + item.limitedNumber + 
						"</td><td style='padding:8px 8px'>" + item.volumeOfCargo + 
						"</td><td style='padding:8px 8px'>" + item.personInCharge + 
						"</td><td style='padding:8px 8px'>" + item.phone + 
						"</td><td style='padding:8px 8px'>" + item.remarks +
						'<td>' +
							'<button class="btn btn-xs btn-info" onclick="modify(this);" style="width:50%;height:100%;float:left" >' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-success" onclick="del(this);" style="width:50%;height:100%;">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                  
							
                });
				$loading.html("");
				$tbody.html(str);
				page = new Page(8, 'sample-table-1', 'sample-tbody-1');
				document.getElementById("form-m").reset();
			}
		}
	});
}
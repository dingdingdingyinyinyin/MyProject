//物流信息文字显示
function transfer(){

	//左边的收件人，发件人的相关信息
	var key=$('#input-search').val();
	$RecipientName=$('#RecipientName');
    $RecipientPhone=$('#RecipientPhone');
	$RecipientAddress=$('#RecipientAddress');
	$SendName=$('#SendName');
	$SendPhone=$('#SendPhone');
	$SendAddress=$('#SendAddress');
	$.ajax({
		type:"POST",
		url:"transfer_search_div.php",
		contentType: "application/x-www-form-urlencoded;charset=utf-8",
        dataType: "json",
		data:{
			key: key
        },
		success:function(data){
			if ($.isEmptyObject(data)) {
				$RecipientName.html("没有相关数据");
			} 
			else {
				$.each(data,function(index, item){
					$RecipientName.html(item.RecipientName);
					$RecipientPhone.html(item.RecipientPhone);
					$RecipientAddress.html(item.RecipientAddress);
					$SendName.html(item.SendName);
					$SendPhone.html(item.SendPhone);
					$SendAddress.html(item.SendAddress);
				});
			}	
		}
	});

	//右边div物流信息
	$loading_ul=$('#loading_ul');
	$transfer_ul=$('#transfer_ul');
	$.ajax({
            type: "POST",
            url: "transfer_search.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "json",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                key: key
            },
			beforeSend: function() {
				$loading_ul.html("正在加载……");	
			},
			error: function() {
				$loading_ul.html("加载失败……");
			},
            success: function(data) {
			if ($.isEmptyObject(data)) {
				$loading_ul.html("没有相关数据");
			} 
			else {
                var str = "";
                $.each(data,function(index, item) {	
					if(item.TransTime15)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime15.substring(0,10)+'</span><span>'+item.TransTime15.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress15+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime14)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime14.substring(0,10)+'</span><span>'+item.TransTime14.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress14+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime13)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime13.substring(0,10)+'</span><span>'+item.TransTime13.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress13+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime12)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime12.substring(0,10)+'</span><span>'+item.TransTime12.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress12+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime11)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime11.substring(0,10)+'</span><span>'+item.TransTime11.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress11+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime10)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime10.substring(0,10)+'</span><span>'+item.TransTime10.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress10+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime9)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime9.substring(0,10)+'</span><span>'+item.TransTime9.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress9+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime8)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime8.substring(0,10)+'</span><span>'+item.TransTime8.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress8+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime7)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime7.substring(0,10)+'</span><span>'+item.TransTime7.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress7+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime6)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime6.substring(0,10)+'</span><span>'+item.TransTime6.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress6+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime5)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime5.substring(0,10)+'</span><span>'+item.TransTime5.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress5+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime4)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime4.substring(0,10)+'</span><span>'+item.TransTime4.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress4+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime3)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime3.substring(0,10)+'</span><span>'+item.TransTime3.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress3+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime2)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime2.substring(0,10)+'</span><span>'+item.TransTime2.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress2+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime1)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime1.substring(0,10)+'</span><span>'+item.TransTime1.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
							'</div>'+
							'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
								'<p>'+item.TransAddress1+'</p>'+
							'</div>'+
						 '</li>';
					}
					str +=  
					'<li>'+
						'<time class="cbp_tmtime" style="margin:0px 15px 0px 0px"><span style="width: 63px;height: 18px;">'+item.TransTime.substring(0,10)+'</span><span>'+item.TransTime.substring(11,19)+'</span></time>'+
						'<div class="cbp_tmicon" style="left:25.5%;weight:5px;height:5px">'+
						'</div>'+
						'<div class="cbp_tmlabel" style="width:250px;margin: 0 0 8px 28%;">'+
							'<p>'+item.RecipientAddress+'已揽件</p>'+
						'</div>'+
					'</li>'
			
                });
				$loading_ul.html("");
				$transfer_ul.html(str);
            }
		}

        });

}

//地图显示：右边的div
function map_view(){
	
	function geocoder(begin_word) {
        var geocoder = new AMap.Geocoder({
           //city: "sichuan", //城市，默认：“全国”
            radius: 1000 //范围，默认：500
        });
        //地理编码,返回地理编码结果
        geocoder.getLocation(begin_word, function(status, result) {
            if (status === 'complete' && result.info === 'OK') {
				longitude=result.geocodes[0].location.getLng();
				latitude=result.geocodes[0].location.getLat();
				addMarker(0, result.geocodes[0]);
            }
        });
    }
	function geocoder_des(end_word,longitude_now,latitude_now) {
        var geocoder = new AMap.Geocoder({
           //city: "sichuan", //城市，默认：“全国”
            radius: 1000 //范围，默认：500
        });
        //地理编码,返回地理编码结果
        geocoder.getLocation(end_word, function(status, result) {
            if (status === 'complete' && result.info === 'OK') {
				longitude_des=result.geocodes[0].location.getLng();
				latitude_des=result.geocodes[0].location.getLat();
				addMarker(0, result.geocodes[0]);
				driving_road(longitude_now,latitude_now);
            }
        });
    }
	//加标记
    function addMarker(i, d) {
        var marker = new AMap.Marker({
            map: map,
            position: [ d.location.getLng(),  d.location.getLat()]
        });
        var infoWindow = new AMap.InfoWindow({
            content: d.formattedAddress,
            offset: {x: 0, y: -30}
        });
        marker.on("mouseover", function(e) {
            infoWindow.open(map, marker.getPosition());
        });
    }
	
	//<!-- 货车路径 -->
    function driving_road(longitude_now,latitude_now){
		var truckOptions = {
				map: map,
				policy:0,
				size:1,
				panel:'panel'
		};
		var driving = new AMap.TruckDriving(truckOptions);
		var path = [];
		//alert(longitude+" "+latitude+" "+longitude_des+" "+latitude_des)
		path.push({lnglat:[longitude,latitude]});//起点
		path.push({lnglat:[longitude_now,latitude_now]});//途径
		path.push({lnglat:[longitude_des,latitude_des]});//终点
		driving.search(path,function(status, result) {
		//TODO something
		});
	}


	//获取起点终点位置
	$loading_ul=$('#loading_ul');
	$transfer_ul=$('#transfer_ul');
	$transfer_ul.html("");
	var key=$('#input-search').val();
	var begin_word;//发件人地址
	var end_word;//收件人地址
	var longitude_now;//目前经度
	var latitude_now;//目前纬度
	var	longitude;//发件人地址转换为经度
	var	latitude;//发件人地址转换为纬度
	var	longitude_des;//收件人地址转换为经度
	var	latitude_des;//收件人地址转换为纬度
	
	//获取起点，终点，途径点的位置并加上标记
	$.ajax({
		type:"POST",
		url:"transfer_search_div.php",
		contentType: "application/x-www-form-urlencoded;charset=utf-8",
        dataType: "json",
		data:{
			key: key
        },
		success:function(data){
			if ($.isEmptyObject(data)) {
				$loading_ul.html("没有相关数据");
			} 
			else {
				$.each(data,function(index, item){
					begin_word=item.SendAddress;
					end_word=item.RecipientAddress;
					longitude_now=item.longitude;
					latitude_now=item.latitude;
					//alert(begin_word+" "+end_word+" "+longitude_now+" "+latitude_now);
					geocoder(begin_word);
					geocoder_des(end_word,longitude_now,latitude_now);
				});
			}	
		}
	});
	
        //地图初始显示当前城市
		var	map	= new AMap.Map('logisticsInformation', {
			  resizeEnable: true
		});
		//map.setFeatures("road");
		map.plugin(["AMap.ToolBar"], function()	{
			map.addControl(new AMap.ToolBar());
		});

		//<!-- 上面是定位，下面是打上标记 -->
		
		var	marker;
		var	icon = new AMap.Icon({
			image: 'http://vdata.amap.com/icons/b18/1/2.png',
			size: new AMap.Size(24,	24)
		});
		marker = new AMap.Marker({
			offset:	new	AMap.Pixel(-12,	-12),
			zIndex:	101,
			map: map
		});
		
}

/*把之前的地图清空，重新加载一遍物流信息*/
function transfer_reload(){
	$logisticsInformation=$('#logisticsInformation');
	$logisticsInformation.removeClass("amap-container");
	$logisticsInformation.removeAttr("style");
	$panel=$('#panel');
	$panel.html("");
	var str='<div id="loading_ul" align="center"></div>'+
			'<ul id="transfer_ul" class="cbp_tmtimeline cbp_tmtimeline_before" style="margin:30px 0px 30px 30px;"></ul>';
	$logisticsInformation.html(str);	
	transfer();
}
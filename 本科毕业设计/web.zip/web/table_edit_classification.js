function getData() {
    var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
    //获取列表
    $.ajax({
        type: "POST",
        url: "classification_information.php",
        dataType: "json",
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
        success: function(data) {
            if ($.isEmptyObject(data)) {
                $loading.html("当前没有数据");
            } else {
                var str = "";
				var flag=0;
                $.each(data,function(index, item) {
					flag++;
                    str += '<tr><td align="center">' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" + flag + 
						"</td><td style='padding:8px 2px'>" + item.RFID + 
						"</td><td style='padding:8px 2px'>" + item.InTheCar + 
						"</td><td style='padding:8px 2px'>" + item.DesAddress + 
						"</td><td style='padding:8px 2px'>" + item.StartAddress + 
						"</td><td style='padding:8px 2px' align='center'>" + item.Num +
						"</td><td style='padding:8px 2px'>" + item.RecipientTime +
						"</td><td style='padding:8px 2px'>" + item.ArriveTime +
						'<td>' +
							'<button class="btn btn-xs btn-info" onclick="detail(this);"style="width:33%;height:100%;float:left">'+
								'<i class="ace-icon fa fa-search-plus bigger-120"></i>'+
							'</button>'+
							'<button class="btn btn-xs btn-success" onclick="modify(this);"style="width:34%;height:100%;" >' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-primary" onclick="del(this);" style="width:33%;height:100%;float:right">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                });
				$tbody.html(str);	
                $loading.html("");
                page = new Page(8, 'sample-table-1', 'sample-tbody-1');
            }
        }
    })
}

//add功能
function addList() {
    var RFID = document.getElementById('RFID-m').value;
	var InTheCar = document.getElementById('InTheCar-m').value;
    var DesAddress = document.getElementById('DesAddress-m').value;
    var StartAddress = document.getElementById('StartAddress-m').value;
    var Num = document.getElementById('Num-m').value;
    var RecipientTime = document.getElementById('RecipientTime-m').value;
    var ArriveTime = document.getElementById('ArriveTime-m').value;
    if (window.confirm("你确定要增加吗？")) {
        $.ajax({
            type: "POST",
            url: "add_classification.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFID: RFID,
				InTheCar:InTheCar,
                StartAddress: StartAddress,
                DesAddress: DesAddress,
                Num: Num,
                RecipientTime: RecipientTime,   
				ArriveTime: ArriveTime
            },
            success: function(data) {
					//alert(data);
                if (data.trim() == "OK") {
                    alert("添加成功");
                    getData();
                } else {
                    alert("添加失败");
                }
            }
        })
			document.getElementById("form-m").reset();
    }

}

//del单点功能
function del(obj) {
    if (window.confirm("你确定要删除吗？")) {
        var temp = $(obj).parent().parent().find("td:eq(2)").text();
        // 发送至php,进行数据库的更改		
        $.ajax({
            type: "POST",
            url: "del_classification.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
               RFID: temp
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//全选
function checkAll(c) {
    var status = c.checked;
    var oItems = document.getElementsByName('item');
    for (var i = 0; i < oItems.length; i++) {
        oItems[i].checked = status;
    }
}
//delAll功能
function delAll() {
    if (window.confirm("你确定要删除吗？")) {
        var temp = "";
        var str = "";
        var items = document.getElementsByName("item");
        for (var j = 1; j < items.length; j++) {
            if (items[j].checked) {
                temp = $(items[j]).parent().parent().parent().find("td:eq(2)").text();
					str += "\""+temp +"\""+ ',';
            }
        }
		str = str.substring(0,str.length-1);
        str = '(' + str + ')';
        $.ajax({
            type: "POST",
            url: "delAll_classification.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFIDAll: str
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//modify功能
function modify(obj) {
    var id = document.getElementById('id-m');
    var RFID = document.getElementById('RFID-m');
	RFID.setAttribute("readonly","readonly");
	var InTheCar = document.getElementById('InTheCar-m');
    var DesAddress = document.getElementById('DesAddress-m');
    var StartAddress = document.getElementById('StartAddress-m');
    var Num = document.getElementById('Num-m');
    var RecipientTime = document.getElementById('RecipientTime-m');
    var ArriveTime = document.getElementById('ArriveTime-m');
	
    var oTr = obj.parentNode.parentNode;
    var aTd = oTr.getElementsByTagName('td');
    rowIndex = obj.parentNode.parentNode.rowIndex;
	//for(var i=1;i<14;i++)
	//	alert(aTd[i].innerHTML);
    id.value = aTd[1].innerHTML;
    RFID.value = aTd[2].innerHTML;
	InTheCar.value = aTd[3].innerHTML;
	DesAddress.value = aTd[4].innerHTML;
    StartAddress.value= aTd[5].innerHTML;
	Num.value = aTd[6].innerHTML;
	RecipientTime.value= aTd[7].innerHTML;
	ArriveTime.value=aTd[8].innerHTML;
}
//update功能
function update() {
    var RFID = document.getElementById('RFID-m');
	var InTheCar = document.getElementById('InTheCar-m');
    var DesAddress = document.getElementById('DesAddress-m');
    var StartAddress = document.getElementById('StartAddress-m');
    var Num = document.getElementById('Num-m');
    var RecipientTime = document.getElementById('RecipientTime-m');
    var ArriveTime = document.getElementById('ArriveTime-m');

    if (window.confirm("你确定要修改吗？")) {
        $.ajax({
            type: "POST",
            url: "update_classification.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFID: RFID.value,
				InTheCar: InTheCar.value,
                DesAddress: DesAddress.value,
                StartAddress: StartAddress.value,
                Num: Num.value,
                RecipientTime: RecipientTime.value,
                ArriveTime: ArriveTime.value
            },

            success: function(data) {
                if (data.trim() == "OK") {
                    alert("更新成功");
                    getData();
                } else {
                    alert("更新失败");
                }
            }

        })
		document.getElementById("form-m").reset();
		RFID.removeAttribute("readonly");
    }
}

function detail(obj){
	 var temp = $(obj).parent().parent().find("td:eq(2)").text();
	 window.open('detail_information.html?key='+temp,'newwindow','height=600, width=900, top=100,left=200, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no')
}

function search() {
	var temp = document.getElementById('input-search').value;
	var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
	//alert(temp);
	$.ajax({
		type:"POST",
		url:"search_classification.php",
		contentType: "application/x-www-form-urlencoded;charset=utf-8",
        dataType: "json",
        data: {
			key:temp
		},
		
		beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
		success: function(data) {
			//alert(data);
			if ($.isEmptyObject(data)) {
				$loading.html("没有相关数据");
			} 
			else {
                var str = "";
				var flag=0;
                $.each(data,function(index, item) {
					flag++;
                     str += '<tr><td align="center">' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" +flag+ 
						"</td><td>" + item.RFID + 
						"</td><td>" + item.InTheCar + 
						"</td><td>" + item.DesAddress + 
						"</td><td>" + item.StartAddress + 
						"</td><td>" + item.Num +
						"</td><td>" + item.RecipientTime +
						"</td><td align='center'>" + item.ArriveTime +
						'<td>' +
							'<button class="btn btn-xs btn-info" onclick="modify(this);" style="width:50%;height:100%;float:left" >' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-success" onclick="del(this);" style="width:50%;height:100%;">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                  
							
                });
				$loading.html("");
				$tbody.html(str);
				page = new Page(8, 'sample-table-1', 'sample-tbody-1');
				document.getElementById("form-m").reset();
			}
		}
	});
}
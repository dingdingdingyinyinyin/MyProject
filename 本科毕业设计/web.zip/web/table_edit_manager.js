function getData() {
    var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
    //获取列表
    $.ajax({
        type: "POST",
        url: "manager_information.php",
        dataType: "json",
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
        success: function(data) {
            if ($.isEmptyObject(data)) {
                $loading.html("当前没有数据");
            } else {
                var str = "";
				var flag=0;
                $.each(data,function(index, item) {
					flag++;
                    str += '<tr><td align="center">' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" + flag + 
						"</td><td style='padding:8px 8px'>" + item.username + 
						"</td><td style='padding:8px 8px'>" + item.password + 
						"</td><td style='padding:8px 8px'>" + item.mobilePhone + 
						"</td><td style='padding:8px 8px'>" + item.registerTime + 
						"</td><td style='padding:8px 8px'>" + item.Email + 
						'<td>' +
							'<button class="btn btn-xs btn-success" onclick="modify(this);"style="width:50%;height:100%;float:left" >' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-primary" onclick="del(this);" style="width:50%;height:100%;">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                });
				$tbody.html(str);	
                $loading.html("");
                page = new Page(8, 'sample-table-1', 'sample-tbody-1');
            }
        }
    })
}

//add功能
function addList() {
    var username = document.getElementById('username-m').value;
	var password = document.getElementById('password-m').value;
    var mobilePhone = document.getElementById('mobilePhone-m').value;
    var registerTime = document.getElementById('registerTime-m').value;
	var Email = document.getElementById('Email-m').value;
    if (window.confirm("你确定要增加吗？")) {
        $.ajax({
            type: "POST",
            url: "add_manager.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                username: username,
				password:password,
                mobilePhone: mobilePhone,
                registerTime: registerTime,
                Email: Email
            },
            success: function(data) {
					//alert(data);
                if (data.trim() == "OK") {
                    alert("添加成功");
                    getData();
                } else {
                    alert("添加失败");
                }
            }
        })
			document.getElementById("form-m").reset();
    }

}

//del单点功能
function del(obj) {
    if (window.confirm("你确定要删除吗？")) {
        var temp = $(obj).parent().parent().find("td:eq(2)").text();
        // 发送至php,进行数据库的更改		
        $.ajax({
            type: "POST",
            url: "del_manager.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
               username: temp
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//全选
function checkAll(c) {
    var status = c.checked;
    var oItems = document.getElementsByName('item');
    for (var i = 0; i < oItems.length; i++) {
        oItems[i].checked = status;
    }
}
//delAll功能
function delAll() {
    if (window.confirm("你确定要删除吗？")) {
        var temp = "";
        var str = "";
        var items = document.getElementsByName("item");
        for (var j = 1; j < items.length; j++) {
            if (items[j].checked) {
                temp = $(items[j]).parent().parent().parent().find("td:eq(2)").text();
					str += "\""+temp +"\""+ ',';
            }
        }
		str = str.substring(0,str.length-1);
        str = '(' + str + ')';
        $.ajax({
            type: "POST",
            url: "delAll_manager.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                usernameAll: str
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//modify功能
function modify(obj) {
    var id = document.getElementById('id-m');
    var username = document.getElementById('username-m');
	username.setAttribute("readonly","readonly");
	var password = document.getElementById('password-m');
    var mobilePhone = document.getElementById('mobilePhone-m');
    var registerTime = document.getElementById('registerTime-m');
	var Email = document.getElementById('Email-m');
	
    var oTr = obj.parentNode.parentNode;
    var aTd = oTr.getElementsByTagName('td');
    rowIndex = obj.parentNode.parentNode.rowIndex;
	//for(var i=1;i<14;i++)
	//	alert(aTd[i].innerHTML);
    id.value = aTd[1].innerHTML;
    username.value = aTd[2].innerHTML;
	password.value = aTd[3].innerHTML;
	mobilePhone.value = aTd[4].innerHTML;
	registerTime.value = aTd[5].innerHTML;
    Email.value= aTd[6].innerHTML;
}
//update功能
function update() {
	var id = document.getElementById('id-m');
    var username = document.getElementById('username-m');
	var password = document.getElementById('password-m');
    var mobilePhone = document.getElementById('mobilePhone-m');
    var registerTime = document.getElementById('registerTime-m');
	var Email = document.getElementById('Email-m');

    if (window.confirm("你确定要修改吗？")) {
        $.ajax({
            type: "POST",
            url: "update_manager.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                id: id.value,
				username:username.value,
				password: password.value,
                mobilePhone: mobilePhone.value,
                registerTime: registerTime.value,
                Email: Email.value
            },

            success: function(data) {
                if (data.trim() == "OK") {
                    alert("更新成功");
                    getData();
                } else {
                    alert("更新失败");
                }
            }

        })
		document.getElementById("form-m").reset();
		username.removeAttribute("readonly");
    }
}

function search() {
	var temp = document.getElementById('input-search').value;
	var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
	//alert(temp);
	$.ajax({
		type:"POST",
		url:"search_manager.php",
		contentType: "application/x-www-form-urlencoded;charset=utf-8",
        dataType: "json",
        data: {
			key:temp
		},
		
		beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
		success: function(data) {
			//alert(data);
			if ($.isEmptyObject(data)) {
				$loading.html("没有相关数据");
			} 
			else {
                var str = "";
				var flag=0;
                $.each(data,function(index, item) {
					flag++;
                     str += '<tr><td align="center">' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" + flag + 
						"</td><td style='padding:8px 8px'>" + item.username + 
						"</td><td style='padding:8px 8px'>" + item.password + 
						"</td><td style='padding:8px 8px'>" + item.mobilePhone + 
						"</td><td style='padding:8px 8px'>" + item.registerTime + 
						"</td><td style='padding:8px 8px'>" + item.Email + 
						'<td>' +
							'<button class="btn btn-xs btn-info" onclick="modify(this);" style="width:50%;height:100%;float:left" >' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-success" onclick="del(this);" style="width:50%;height:100%;">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                  
							
                });
				$loading.html("");
				$tbody.html(str);
				page = new Page(8, 'sample-table-1', 'sample-tbody-1');
				document.getElementById("form-m").reset();
			}
		}
	});
}
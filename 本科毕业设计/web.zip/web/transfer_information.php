<?php
	header("content-type:text/html;charset=utf-8");
	$link=@mysql_connect('localhost','root','') or die ('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	mysql_query('set names utf8');
	$RFID=$_POST['RFID'];

	$sql="select * from transfer where RFID='$RFID'";
	$result=mysql_query($sql);
	$rs=mysql_num_rows($result);
	$dataList=array();
	while($row=mysql_fetch_assoc($result))
	{
		$dataList[]=array("id"=>$row['id'],"RFID"=>$row['RFID'],"OrderNum"=>$row['OrderNum'],"RecipientAddress"=>$row['RecipientAddress'],"TransTime"=>$row['TransTime'],"SendAddress"=>$row['SendAddress'],"State"=>$row['State'],
			"TransAddress1"=>$row['TransAddress1'],"TransAddress2"=>$row['TransAddress2'],"TransAddress3"=>$row['TransAddress3'],"TransAddress4"=>$row['TransAddress4'],"TransAddress5"=>$row['TransAddress5'],"TransAddress6"=>$row['TransAddress6'],"TransAddress7"=>$row['TransAddress7'],"TransAddress8"=>$row['TransAddress8'],"TransAddress9"=>$row['TransAddress9'],"TransAddress10"=>$row['TransAddress10'],"TransAddress11"=>$row['TransAddress11'],"TransAddress12"=>$row['TransAddress12'],"TransAddress13"=>$row['TransAddress13'],"TransAddress14"=>$row['TransAddress14'],"TransAddress15"=>$row['TransAddress15'],"TransTime1"=>$row['TransTime1'],"TransTime2"=>$row['TransTime2'],"TransTime3"=>$row['TransTime3'],"TransTime4"=>$row['TransTime4'],"TransTime5"=>$row['TransTime5'],"TransTime6"=>$row['TransTime6'],"TransTime7"=>$row['TransTime7'],"TransTime8"=>$row['TransTime8'],"TransTime9"=>$row['TransTime9'],"TransTime10"=>$row['TransTime10'],"TransTime11"=>$row['TransTime11'],"TransTime12"=>$row['TransTime12'],"TransTime13"=>$row['TransTime13'],"TransTime14"=>$row['TransTime14'],"TransTime15"=>$row['TransTime15']);
	}
	echo json_encode($dataList);
?>
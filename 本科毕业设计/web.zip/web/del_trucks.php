<?php
	header("content-type:text/html;charset=utf8");
	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	//mysql_select_db('rfid') or die('数据库选择失败');
	mysql_query('set names utf8');

	$number=$_POST['number'];
	$sql="delete from trucks_information where plateNumber='$number'";
	$result=mysql_query($sql);
	$rs=mysql_affected_rows();
	if($rs){
		echo 'OK';
	}
	else{
		echo "NO";
	}
?>
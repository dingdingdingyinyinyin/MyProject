<?php
	header("content-type:text/html;charset=utf8");
	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	//mysql_select_db('rfid') or die('数据库选择失败');
	mysql_query('set names utf8');
	//例$idAll=(1,2,3)
	$idAll=$_POST['idAll'];
	if(mysql_query("delete from package_information where RFID in $idAll;")){
		echo 'OK';
	}
	else{
		echo "NO";
	}

?>
<?php
	header("content-type:text/html;charset=utf8");
	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	//mysql_select_db('rfid') or die('数据库选择失败');
	mysql_query('set names utf8');
	$RFID=$_POST['RFID'];
	$StartAddress=$_POST['StartAddress'];
	$DesAddress=$_POST['DesAddress'];
	$Num=$_POST['Num'];
	$RecipientTime=$_POST['RecipientTime'];
	$ArriveTime=$_POST['ArriveTime'];
	$Driver=$_POST['Driver'];
	$DriverPhone=$_POST['DriverPhone'];
	$sql="update package_entrucking set StartAddress='$StartAddress', 
		DesAddress='$DesAddress', Num='$Num', RecipientTime='$RecipientTime', ArriveTime='$ArriveTime', Driver='$Driver', DriverPhone='$DriverPhone'where RFID='$RFID'";
	/*
	$result = mysql_affected_rows(); 
	如果$result 值为-1表明语句没有成功执行，可能是语句格式有问题等等；
	如果$result 值为0 表明语句成功执行，但是update并没有改变数据表任何一个字段的值；
	如果$result值为1 表明语句成功执行， 而且update改变了数据表的某个或者多个字段的值；
	*/
	 $result = mysql_query($sql);
	 $rs=mysql_affected_rows();
	if($rs){
		echo 'OK';
	}
	else{
		echo 'NO';
	}
?>
function getStatisticalInformation(){
	var $Allpackages=$('#Allpackages');
	var $Allboxs=$('#Allboxs');
	var $Alltrucks=$('#Alltrucks');
	var $packages=$('#packages');
	var $boxs=$('#boxs');
	var $trucks=$('#trucks');
	$.ajax({
	type:"POST",
		url:"statistical_information.php",
		dataType:"TEXT",
		contentType: "application/x-www-form-urlencoded; charset=UTF-8",
		success: function(data) {
				var num=data.split(" ");
				$Allpackages.html(num[0]);
				$packages.html(num[1]);
				$Allboxs.html(num[2]);
				$boxs.html(num[3]);
				$Alltrucks.html(num[4]);	
				$trucks.html(num[5]);
				var $percent1=(100-num[1]/num[0]*100).toFixed(2)+'%';
				var $percent2=(100-num[5]/num[4]*100).toFixed(2)+'%';
				$("#data-percent-style1").width($percent1);
				$("#data-percent-style1").html('包裹：'+$percent1);
				$("#data-percent-style2").width($percent2);
				$("#data-percent-style2").html('车辆：'+$percent2);

            }
	});
}
function getData() {
    var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
    //获取列表
    $.ajax({
        type: "POST",
        url: "package_information.php",
        dataType: "json",
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
        success: function(data) {
            if ($.isEmptyObject(data)) {
                $loading.html("当前没有数据");
            } else {
                var str = "";
                $.each(data,function(index, item) {
                    str += '<tr><td style="padding:8px 5px">' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" + item.id + 
						"</td><td style='padding:8px 1px'>" + item.RFID + 
						"</td><td style='padding:8px 1px'>" + item.OrderNum + 
						"</td><td style='padding:8px 2px'>" + item.RecipientName + 
						"</td><td style='padding:8px 1px'>" + item.RecipientPhone + 
						"</td><td style='padding:8px 1px'>" + item.RecipientAddress +
						//"</td><td>"+item.Remarks+
						"</td><td style='padding:8px 2px'>" + item.SendName +
						"</td><td style='padding:8px 1px'>" + item.SendPhone + 
						"</td><td style='padding:8px 1px'>" + item.SendAddress +
						"</td><td style='padding:8px 1px'>" + item.RecipientTime +
						"</td><td align='center'>" + item.State +
						"</td><td style='padding:8px 1px'>"+item.GroupNum+
						"</td><td style='padding:8px 1px'>"+item.CarNum+
						//"</td><td>"+""+
						'<td>' +
							'<button class="btn btn-xs btn-info" onclick="modify(this);" style="width:50%;height:100%;float:left" >' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-success" onclick="del(this);" style="width:50%;height:100%;">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                    /*
							'<td><div>'+
								'<input type="button" name="" value="删除" class="btn btn-danger" onclick="del(this)" />'+
								'<input type="button" name="" value="修改" class="btn btn-info" onclick="modify(this)" />'+
								
							'</div></td>'+
							"</td></tr>"
							*/
                });
				$tbody.html(str);	
                $loading.html("");
                page = new Page(5, 'sample-table-1', 'sample-tbody-1');
            }
        }
    })
}

//add功能
function addList() {
    var id = document.getElementById('id-m').value;
    var RFID = document.getElementById('RFID-m').value;
    var OrderNum = document.getElementById('OrderNum-m').value;
    var RecipientName = document.getElementById('RecipientName-m').value;
    var RecipientPhone = document.getElementById('RecipientPhone-m').value;
    var RecipientAddress = document.getElementById('RecipientAddress-m').value;
    var SendName = document.getElementById('SendName-m').value;
    var SendPhone = document.getElementById('SendPhone-m').value;
    var SendAddress = document.getElementById('SendAddress-m').value;
    var RecipientTime = document.getElementById('RecipientTime-m').value;
    var State = document.getElementById('State-m').value;
	var GroupNum=document.getElementById('GroupNum-m').value;
	var CarNum=document.getElementById('CarNum-m').value;
    if (window.confirm("你确定要增加吗？")) {
        $.ajax({
            type: "POST",
            url: "add.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFID: RFID,
                OrderNum: OrderNum,
                RecipientName: RecipientName,
                RecipientPhone: RecipientPhone,
                RecipientAddress: RecipientAddress,
                SendName: SendName,
                SendPhone: SendPhone,
                SendAddress: SendAddress,
                RecipientTime: RecipientTime,   
				State: State,
				GroupNum: GroupNum,
				CarNum: CarNum
            },
            success: function(data) {
					//alert(data);
                if (data.trim() == "OK") {
                    alert("添加成功");
                    getData();
                } else {
                    alert("添加失败");
                }
            }
        })
    }

}

//del单点功能
function del(obj) {
    if (window.confirm("你确定要删除吗？")) {
        var temp = $(obj).parent().parent().find("td:eq(1)").text();
        // 发送至php,进行数据库的更改		
        $.ajax({
            type: "POST",
            url: "del.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                id: temp
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//全选
function checkAll(c) {
    var status = c.checked;
    var oItems = document.getElementsByName('item');
    for (var i = 0; i < oItems.length; i++) {
        oItems[i].checked = status;
    }
}
//delAll功能
function delAll() {
    if (window.confirm("你确定要删除吗？")) {
        var temp = "";
        var str = "";
        var items = document.getElementsByName("item");
        for (var j = 1; j < items.length; j++) {
            if (items[j].checked) {
                temp = $(items[j]).parent().parent().parent().find("td:eq(1)").text();
                if (j < items.length - 1) str += temp + ',';
                else str += temp
            }
        }
        str = '(' + str + ')';
        //alert(str);
        $.ajax({
            type: "POST",
            url: "delAll.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                idAll: str
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//modify功能
function modify(obj) {
    var id = document.getElementById('id-m');
    var RFID = document.getElementById('RFID-m');
    var OrderNum = document.getElementById('OrderNum-m');
    var RecipientName = document.getElementById('RecipientName-m');
    var RecipientPhone = document.getElementById('RecipientPhone-m');
    var RecipientAddress = document.getElementById('RecipientAddress-m');
    var SendName = document.getElementById('SendName-m');
    var SendPhone = document.getElementById('SendPhone-m');
    var SendAddress = document.getElementById('SendAddress-m');
    var RecipientTime = document.getElementById('RecipientTime-m');
    var State = document.getElementById('State-m');
	var GroupNum=document.getElementById('GroupNum-m');
	var CarNum=document.getElementById('CarNum-m');

    var oTr = obj.parentNode.parentNode;
    var aTd = oTr.getElementsByTagName('td');
    rowIndex = obj.parentNode.parentNode.rowIndex;
	//for(var i=1;i<14;i++)
	//	alert(aTd[i].innerHTML);
    id.value = aTd[1].innerHTML;
    RFID.value = aTd[2].innerHTML;
	OrderNum.value = aTd[3].innerHTML;
    RecipientName.value= aTd[4].innerHTML;
	RecipientPhone.value = aTd[5].innerHTML;
	RecipientAddress.value= aTd[6].innerHTML;
	SendName.value=aTd[7].innerHTML;
    SendPhone.value = aTd[8].innerHTML;
    SendAddress.value = aTd[9].innerHTML;
    //alert(RecipientPhone.value);
    RecipientTime.value = aTd[10].innerHTML;
    State.value = aTd[11].innerHTML; 
    GroupNum.value = aTd[12].innerHTML;
	CarNum.value = aTd[13].innerHTML;
}
//update功能
function update() {
    var id = document.getElementById('id-m');
    var RFID = document.getElementById('RFID-m');
    var OrderNum = document.getElementById('OrderNum-m');
    var RecipientName = document.getElementById('RecipientName-m');
    var RecipientPhone = document.getElementById('RecipientPhone-m');
    var RecipientAddress = document.getElementById('RecipientAddress-m');
    var SendName = document.getElementById('SendName-m');
    var SendPhone = document.getElementById('SendPhone-m');
    var SendAddress = document.getElementById('SendAddress-m');
    var RecipientTime = document.getElementById('RecipientTime-m');
	var State=document.getElementById('State-m');
    var GroupNum = document.getElementById('GroupNum-m');
    var CarNum = document.getElementById('CarNum-m');

    if (window.confirm("你确定要修改吗？")) {
        $.ajax({
            type: "POST",
            url: "update.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                id: id.value,
                RFID: RFID.value,
                OrderNum: OrderNum.value,
                RecipientName: RecipientName.value,
                RecipientPhone: RecipientPhone.value,
                RecipientAddress: RecipientAddress.value,
                SendName: SendName.value,
                SendPhone: SendPhone.value,
                SendAddress: SendAddress.value,
                RecipientTime: RecipientTime.value,
                State: State.value,
				GroupNum: GroupNum.value,
				CarNum: CarNum.value
            },

            success: function(data) {
                if (data.trim() == "OK") {
                    alert("更新成功");
                    getData();
                } else {
                    alert("更新失败");
                }
            }

        })
    }
}

function search() {
	var temp = document.getElementById('input-search').value;
	var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
	//alert(temp);
	$.ajax({
		type:"POST",
		url:"search.php",
		contentType: "application/x-www-form-urlencoded;charset=utf-8",
        dataType: "json",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
        data: {
			key:temp
		},
		
		beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
		success: function(data) {
			//alert(data);
			if ($.isEmptyObject(data)) {
				$loading.html("没有相关数据");
			} 
			else {
                var str = "";
                $.each(data,function(index, item) {
                    str += '<tr><td>' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" + item.id + 
						"</td><td align='center'>" + item.RFID + 
						"</td><td align='center'>" + item.OrderNum + 
						"</td><td>" + item.RecipientName + 
						"</td><td>" + item.RecipientPhone + 
						"</td><td>" + item.RecipientAddress +
						//"</td><td>"+item.Remarks+
						"</td><td>" + item.SendName +
						"</td><td>" + item.SendPhone + 
						"</td><td>" + item.SendAddress +
						"</td><td>" + item.RecipientTime +
						"</td><td align='center'>" + item.State +
						"</td><td>"+item.GroupNum+
						"</td><td>"+item.CarNum+
						//"</td><td>"+""+
						'<td>' +
							'<button class="btn btn-xs btn-info" onclick="modify(this);" style="width:50%;height:100%;float:left" >' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-success" onclick="del(this);" style="width:50%;height:100%;">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                  
							
                });
				$loading.html("");
				$tbody.html(str);
				page = new Page(5, 'sample-table-1', 'sample-tbody-1');
			}
		}
	});
}

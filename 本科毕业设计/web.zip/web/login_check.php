<?php
//button的name:submit-btn
if(isset($_POST['submit-btn'])){
		require('./conn.php');
		//接收客户端的传值
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		//构造sql语句查询验证

		$password = md5( $password );		
		$sql = "SELECT * FROM `manager` where username='$username' and 
				password='$password' ";
		$rs = mysqli_query($conn,$sql);
		if( mysqli_num_rows( $rs )>0 ){
			//开启session
			session_start();
			$_SESSION['username'] = $username;	
			$row = mysqli_fetch_assoc( $rs );
		//	$_SESSION['permissionLevel'] = $row['permissionLevel'];	
			//使用js弹出框来实现提示，随后跳转到 map.html
			echo '<script>location.href="./index.html";
				</script>';	
		}else{
			//使用js弹出框来实现提示，随后跳转到 login.html
			echo '<script>alert("用户名或者密码错误！");location.href="./login.html";
				</script>';	
		}
		
}
?>
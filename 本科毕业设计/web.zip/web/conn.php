﻿<?php
header('Content-Type:text/html;charset=utf-8');

//连接数据库
$conn=@mysqli_connect('localhost','root','','rfid') or die('mysql connect error');
mysqli_query($conn,'set names utf8');

?>
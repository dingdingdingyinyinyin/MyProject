<?php
	header("content-type:text/html;charset=utf8");
	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	//mysql_select_db('rfid') or die('数据库选择失败');
	mysql_query('set names utf8');
	//例$idAll=(1,2,3)
	$usernameAll=$_POST['usernameAll'];
	$str="DELETE FROM manager WHERE username IN $usernameAll";
	$result=mysql_query($str);
	$rs=mysql_affected_rows();
	if($rs){
		echo 'OK';
	}
	else{
		echo "NO";
	}

?>
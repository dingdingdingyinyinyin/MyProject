<?php
	header("content-type:text/html;charset=utf8");
	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	mysql_query('set names utf8');
	$key=$_POST['key'];

	$sql="SELECT * FROM package_information WHERE RFID = '$key' or OrderNum = '$key' or RecipientName = '$key' or RecipientPhone = '$key' or SendName = '$key' or SendPhone = '$key'";
	$result=mysql_query($sql);
	$rs=mysql_num_rows($result);
	$dataList=array();
	while($row=mysql_fetch_assoc($result))
	{
		$dataList[]=array("id"=>$row['id'],"RFID"=>$row['RFID'],"OrderNum"=>$row['OrderNum'],
					"RecipientName"=>$row['RecipientName'],"RecipientPhone"=>$row['RecipientPhone'],"RecipientAddress"=>$row['RecipientAddress'],
					"Remarks"=>$row['Remarks'],
					"SendName"=>$row['SendName'],"SendPhone"=>$row['SendPhone'],"SendAddress"=>$row['SendAddress'],
					"RecipientTime"=>$row['RecipientTime'],"State"=>$row['State'],"GroupNum"=>$row['GroupNum'],"CarNum"=>$row['CarNum']);
	}
	echo json_encode($dataList);
?>
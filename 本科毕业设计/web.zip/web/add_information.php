<?php
	header("content-type:text/html;charset=utf8");
	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	//mysql_select_db('rfid') or die('数据库选择失败');
	mysql_query('set names utf8');

	$RFID=$_POST['RFID'];
	$OrderNum=$_POST['OrderNum'];
	$RecipientName=$_POST['RecipientName'];
	$RecipientPhone=$_POST['RecipientPhone'];
	$RecipientAddress=$_POST['RecipientAddress'];
	$SendName=$_POST['SendName'];
	$SendPhone=$_POST['SendPhone'];
	$SendAddress=$_POST['SendAddress'];
	$RecipientTime=$_POST['RecipientTime'];
	$State=$_POST['State'];
	$GroupNum=$_POST['GroupNum'];
	$CarNum=$_POST['CarNum'];
	$sql="insert into package_information(
				RFID,OrderNum,RecipientName,RecipientPhone,RecipientAddress,
				SendName,SendPhone,SendAddress,RecipientTime,State,GroupNum,CarNum) 
				values('$RFID','$OrderNum','$RecipientName','$RecipientPhone','$RecipientAddress'
				,'$SendName','$SendPhone','$SendAddress','$RecipientTime','$State','$GroupNum','$CarNum')";
	/*
	$sql="update package_information set RFID='$RFID', OrderNum='$OrderNum', RecipientName='$RecipientName', RecipientPhone='$RecipientPhone', RecipientAddress='$RecipientAddress', SendName='$SendName', SendPhone='$SendPhone', SendAddress='$SendAddress', RecipientTime='$RecipientTime', State='$State' where id='$id'";
	*/
	/*
	$result = mysql_affected_rows(); 
	如果$result 值为-1表明语句没有成功执行，可能是语句格式有问题等等；
	如果$result 值为0 表明语句成功执行，但是update并没有改变数据表任何一个字段的值；
	如果$result 值为1 表明语句成功执行， 而且update改变了数据表的某个或者多个字段的值；
	*/
	 $result = mysql_query($sql);
	 $rs=mysql_affected_rows();
	if($rs){
		echo 'OK';
	}
	else{
		echo "NO";
	}
?>
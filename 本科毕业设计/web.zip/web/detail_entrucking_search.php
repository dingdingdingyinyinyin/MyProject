<?php
	header("content-type:text/html;charset=utf8");
	$link=@mysql_connect('localhost','root','') or die('数据库连接失败');
	mysql_query('use rfid') or die('数据库选择失败');
	mysql_query('set names utf8');
	$key=$_POST['key'];

	$sql="SELECT * FROM package_classification WHERE InTheCar = '$key'";
	$result=mysql_query($sql);
	$rs=mysql_num_rows($result);
	$dataList=array();
	while($row=mysql_fetch_assoc($result))
	{
		//将结果集 result 的内容选择需要的整理并放在 $dataList 中
		$dataList[]=array("id"=>$row['id'],"RFID"=>$row['RFID'],"InTheCar"=>$row['InTheCar'],"DesAddress"=>$row['DesAddress'],
						"StartAddress"=>$row['StartAddress'],"Num"=>$row['Num'],
						"RecipientTime"=>$row['RecipientTime'],"ArriveTime"=>$row['ArriveTime']);
	}
	echo json_encode($dataList);
?>
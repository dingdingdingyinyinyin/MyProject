function getData() {
    var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
    //获取列表
    $.ajax({
        type: "POST",
        url: "package_information.php",
        dataType: "json",
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
        success: function(data) {
            if ($.isEmptyObject(data)) {
                $loading.html("当前没有数据");
            } else {
                var str = "";
				var flag=0;
				var a1='<a href = "javascript:void(0)" onclick = "transfer(this)">'
                var a2='</a>';
				$.each(data,function(index, item) {
					flag++;
                    str += '<tr><td style="padding:8px 5px">' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" + flag + 
						"</td><td style='padding:8px 1px'>" + a1+item.RFID +a2+ 
						"</td><td style='padding:8px 1px'>" + item.OrderNum + 
						"</td><td style='padding:8px 2px'>" + item.RecipientName + 
						"</td><td style='padding:8px 1px'>" + item.RecipientPhone + 
						"</td><td style='padding:8px 1px'>" + item.RecipientAddress +
						//"</td><td>"+item.Remarks+
						"</td><td style='padding:8px 2px'>" + item.SendName +
						"</td><td style='padding:8px 1px'>" + item.SendPhone + 
						"</td><td style='padding:8px 1px'>" + item.SendAddress +
						"</td><td style='padding:8px 1px'>" + item.RecipientTime +
						"</td><td align='center'>" + item.State +
						"</td><td style='padding:8px 1px'>"+item.GroupNum+
						"</td><td style='padding:8px 1px'>"+item.CarNum+
						//"</td><td>"+""+
						"<td style='padding:8px 1px'>" +
							/*
							'<button class="btn btn-xs btn-info" onclick="detail(this);" style="width:33%;height:100%;float:left">'+
								'<i class="ace-icon fa fa-search-plus"></i>'+
							'</button>'+
							*/
							'<button class="btn btn-xs btn-success" onclick="modify(this);" style="width:50%;height:100%;">' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-primary" onclick="del(this);" style="width:50%;height:100%;float:right">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                    /*
							'<td><div>'+
								'<input type="button" name="" value="删除" class="btn btn-danger" onclick="del(this)" />'+
								'<input type="button" name="" value="修改" class="btn btn-info" onclick="modify(this)" />'+
								
							'</div></td>'+
							"</td></tr>"
							*/
                });
				$tbody.html(str);	
                $loading.html("");
                page = new Page(5, 'sample-table-1', 'sample-tbody-1');
            }
        }
    })
}

//add功能
function addList() {
    var RFID = document.getElementById('RFID-m').value;
    var OrderNum = document.getElementById('OrderNum-m').value;
    var RecipientName = document.getElementById('RecipientName-m').value;
    var RecipientPhone = document.getElementById('RecipientPhone-m').value;
    var RecipientAddress = document.getElementById('RecipientAddress-m').value;
    var SendName = document.getElementById('SendName-m').value;
    var SendPhone = document.getElementById('SendPhone-m').value;
    var SendAddress = document.getElementById('SendAddress-m').value;
    var RecipientTime = document.getElementById('RecipientTime-m').value;
    var State = document.getElementById('State-m').value;
	var GroupNum=document.getElementById('GroupNum-m').value;
	var CarNum=document.getElementById('CarNum-m').value;
    if (window.confirm("你确定要增加吗？")) {
        $.ajax({
            type: "POST",
            url: "add_information.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFID: RFID,
                OrderNum: OrderNum,
                RecipientName: RecipientName,
                RecipientPhone: RecipientPhone,
                RecipientAddress: RecipientAddress,
                SendName: SendName,
                SendPhone: SendPhone,
                SendAddress: SendAddress,
                RecipientTime: RecipientTime,   
				State: State,
				GroupNum: GroupNum,
				CarNum: CarNum
            },
            success: function(data) {
					//alert(data);
                if (data.trim() == "OK") {
                    alert("添加成功");
                    getData();
                } else {
                    alert("添加失败");
                }
            }
        })
			document.getElementById("form-m").reset();		
    }

}

//del单点功能
function del(obj) {
    if (window.confirm("你确定要删除吗？")) {
        var temp = $(obj).parent().parent().find("td:eq(2)").text();
        // 发送至php,进行数据库的更改		
        $.ajax({
            type: "POST",
            url: "del_information.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFID: temp
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//全选
function checkAll(c) {
    var status = c.checked;
    var oItems = document.getElementsByName('item');
    for (var i = 0; i < oItems.length; i++) {
        oItems[i].checked = status;
    }
}
//delAll功能
function delAll() {
    if (window.confirm("你确定要删除吗？")) {
        var temp = "";
        var str = "";
        var items = document.getElementsByName("item");
         for (var j = 1; j < items.length; j++) {
            if (items[j].checked) {
                temp = $(items[j]).parent().parent().parent().find("td:eq(2)").text();
					str += "\""+temp +"\""+ ',';
            }
        }
		str = str.substring(0,str.length-1);
        str = '(' + str + ')';
        //alert(str);
        $.ajax({
            type: "POST",
            url: "delAll_information.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFIDAll: str
            },
            success: function(data) {
                if (data.trim() == "OK") {
                    alert("删除成功");
                    getData();
                } else {
                    alert("删除失败");
                }
            }
        })
    }
}
//modify功能
function modify(obj) {
    var id = document.getElementById('id-m');
    var RFID = document.getElementById('RFID-m');
	RFID.setAttribute("readonly","readonly");
    var OrderNum = document.getElementById('OrderNum-m');
    var RecipientName = document.getElementById('RecipientName-m');
    var RecipientPhone = document.getElementById('RecipientPhone-m');
    var RecipientAddress = document.getElementById('RecipientAddress-m');
    var SendName = document.getElementById('SendName-m');
    var SendPhone = document.getElementById('SendPhone-m');
    var SendAddress = document.getElementById('SendAddress-m');
    var RecipientTime = document.getElementById('RecipientTime-m');
    var State = document.getElementById('State-m');
	var GroupNum=document.getElementById('GroupNum-m');
	var CarNum=document.getElementById('CarNum-m');

    var oTr = obj.parentNode.parentNode;
    var aTd = oTr.getElementsByTagName('td');
	//获取a标签中的内容
	var a = aTd[2].getElementsByTagName('a');
    rowIndex = obj.parentNode.parentNode.rowIndex;
	//for(var i=1;i<14;i++)
	//	alert(aTd[i].innerHTML);
    id.value = aTd[1].innerHTML;
	RFID.value = a[0].innerHTML;
	OrderNum.value = aTd[3].innerHTML;
    RecipientName.value= aTd[4].innerHTML;
	RecipientPhone.value = aTd[5].innerHTML;
	RecipientAddress.value= aTd[6].innerHTML;
	SendName.value=aTd[7].innerHTML;
    SendPhone.value = aTd[8].innerHTML;
    SendAddress.value = aTd[9].innerHTML;
    //alert(RecipientPhone.value);
    RecipientTime.value = aTd[10].innerHTML;
    State.value = aTd[11].innerHTML; 
    GroupNum.value = aTd[12].innerHTML;
	CarNum.value = aTd[13].innerHTML;
}
//update功能
function update() {
    var RFID = document.getElementById('RFID-m');	
    var OrderNum = document.getElementById('OrderNum-m');
    var RecipientName = document.getElementById('RecipientName-m');
    var RecipientPhone = document.getElementById('RecipientPhone-m');
    var RecipientAddress = document.getElementById('RecipientAddress-m');
    var SendName = document.getElementById('SendName-m');
    var SendPhone = document.getElementById('SendPhone-m');
    var SendAddress = document.getElementById('SendAddress-m');
    var RecipientTime = document.getElementById('RecipientTime-m');
	var State=document.getElementById('State-m');
    var GroupNum = document.getElementById('GroupNum-m');
    var CarNum = document.getElementById('CarNum-m');

    if (window.confirm("你确定要修改吗？")) {
        $.ajax({
            type: "POST",
            url: "update_information.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "TEXT",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFID: RFID.value,
                OrderNum: OrderNum.value,
                RecipientName: RecipientName.value,
                RecipientPhone: RecipientPhone.value,
                RecipientAddress: RecipientAddress.value,
                SendName: SendName.value,
                SendPhone: SendPhone.value,
                SendAddress: SendAddress.value,
                RecipientTime: RecipientTime.value,
                State: State.value,
				GroupNum: GroupNum.value,
				CarNum: CarNum.value
            },

            success: function(data) {
                if (data.trim() == "OK") {
                    alert("更新成功");
                    getData();
                } else {
                    alert("更新失败");
                }
            }

        })
		document.getElementById("form-m").reset();		
		RFID.removeAttribute("readonly");
    }
}
function transfer(obj){
	document.getElementById('light').style.display='block';
	document.getElementById('fade').style.display='block';
	document.getElementById('cbp_tmtimeline');
	var RFID=$(obj).text();
	$loading_ul=$('#loading_ul');
	$ul=$('#transfer_ul');
	//alert(RFID);
	$.ajax({
            type: "POST",
            url: "transfer_information.php",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
            dataType: "json",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
            data: {
                RFID: RFID
            },
			beforeSend: function() {
				$loading_ul.html("正在加载……");	
			},
			error: function() {
				$loading_ul.html("加载失败……");
			},
            success: function(data) {
			if ($.isEmptyObject(data)) {
				$loading_ul.html("没有相关数据");
			} 
			else {
                var str = "";
                $.each(data,function(index, item) {
                    str +=  
					'<li>'+
						'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime.substring(0,10)+'</span><span>'+item.TransTime.substring(11,19)+'</span></time>'+
						'<div class="cbp_tmicon">'+
						'</div>'+
						'<div class="cbp_tmlabel">'+
							'<p>'+item.SendAddress+'已揽件</p>'+
						'</div>'+
					'</li>'
					if(item.TransTime1)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime1.substring(0,10)+'</span><span>'+item.TransTime1.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress1+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime2)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime2.substring(0,10)+'</span><span>'+item.TransTime2.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress2+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime3)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime3.substring(0,10)+'</span><span>'+item.TransTime3.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress3+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime4)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime4.substring(0,10)+'</span><span>'+item.TransTime4.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress4+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime5)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime5.substring(0,10)+'</span><span>'+item.TransTime5.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress5+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime6)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime6.substring(0,10)+'</span><span>'+item.TransTime6.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress6+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime7)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime7.substring(0,10)+'</span><span>'+item.TransTime7.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress7+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime8)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime8.substring(0,10)+'</span><span>'+item.TransTime8.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress8+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime9)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime9.substring(0,10)+'</span><span>'+item.TransTime9.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress9+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime10)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime10.substring(0,10)+'</span><span>'+item.TransTime10.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress10+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime11)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime11.substring(0,10)+'</span><span>'+item.TransTime11.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress11+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime12)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime12.substring(0,10)+'</span><span>'+item.TransTime12.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress12+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime13)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime13.substring(0,10)+'</span><span>'+item.TransTime13.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress13+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime14)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime14.substring(0,10)+'</span><span>'+item.TransTime14.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress14+'</p>'+
							'</div>'+
						 '</li>';
					}
					if(item.TransTime15)
					{
						str+=
						'<li>'+
							'<time class="cbp_tmtime" datetime="2014-03-8 11:10"><span>'+item.TransTime15.substring(0,10)+'</span><span>'+item.TransTime15.substring(11,19)+'</span></time>'+
							'<div class="cbp_tmicon">'+
							'</div>'+
							'<div class="cbp_tmlabel">'+
								'<p>'+item.TransAddress15+'</p>'+
							'</div>'+
						 '</li>';
					}
                });
				$loading_ul.html("");
				$ul.html(str);
            }
		}

        });

}
function search() {
	var temp = document.getElementById('input-search').value;
	var $tbody = $("table tbody:eq(0)");
	var $items = $("tbody tr");
	var $loading = $("#loading");
	$.ajax({
		type:"POST",
		url:"search_information.php",
		contentType: "application/x-www-form-urlencoded;charset=utf-8",
        dataType: "json",
            //返回的数据类型，TEXT字符串 JSON返回JSON XML返回XML；dataType中T要大写！！
        data: {
			key:temp
		},
		
		beforeSend: function() {
            $tbody.html("");
			$loading.html("正在加载……");
        },
        error: function() {
            $loading.html("加载失败……");
            //result('获取数据失败……')
        },
		success: function(data) {
			//alert(data);
			if ($.isEmptyObject(data)) {
				$loading.html("没有相关数据");
			} 
			else {
                var str = "";
				var flag=0;
                $.each(data,function(index, item) {
					flag++;
                    str += '<tr><td>' + 
							'<label class="position-relative">' + 
								'<input type="checkbox" class="ace" name="item"/>' + 
								'<span class="lbl"></span>' + 
							'</label>' + 
						'</td>' + 
						"<td align='center'>" + flag + 
						"</td><td align='center'>" + item.RFID + 
						"</td><td align='center'>" + item.OrderNum + 
						"</td><td>" + item.RecipientName + 
						"</td><td>" + item.RecipientPhone + 
						"</td><td>" + item.RecipientAddress +
						//"</td><td>"+item.Remarks+
						"</td><td>" + item.SendName +
						"</td><td>" + item.SendPhone + 
						"</td><td>" + item.SendAddress +
						"</td><td>" + item.RecipientTime +
						"</td><td align='center'>" + item.State +
						"</td><td>"+item.GroupNum+
						"</td><td>"+item.CarNum+
						//"</td><td>"+""+
						'<td>' +
							'<button class="btn btn-xs btn-info" onclick="modify(this);" style="width:50%;height:100%;float:left" >' + 
								'<i class="ace-icon fa fa-pencil bigger-120"></i>' + 
							'</button>' +
							'<button class="btn btn-xs btn-success" onclick="del(this);" style="width:50%;height:100%;">' + 
								'<i class="ace-icon fa fa-trash-o bigger-120"></i>' + 
							'</button>' + 
						"</td></tr>"
                  
							
                });
				$loading.html("");
				$tbody.html(str);
				page = new Page(5, 'sample-table-1', 'sample-tbody-1');
			}
		}
	});
	document.getElementById("form-m").reset();		
}
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Map;
import java.util.Set;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;

import org.xvolks.jnative.exceptions.NativeException;
import org.xvolks.jnative.pointers.Pointer;
import org.xvolks.jnative.pointers.memory.MemoryBlockFactory;

import sendInfo.SendMessage;

import com.syc.function.Function;

public class mainWindow{
	/*-----------------------�Ŀ��-----------------------*/
	private JFrame frame;
	private JTextField RFIDNumText;
	private JTextField OrderNumText;
	private JTextField NameReText;
	private JTextField PhoneReText;
	private JTextField AddressReText;
	private JTextField PhoneSeText;
	private JTextField NameSeText;
	private JTextField AddressSeText;
	private JTextField PsText;
	private JComboBox comboBox;
	private JComboBox cityComboBox;
	private JComboBox comboBox_1;
	private JComboBox cityComboBox_1;
//	JTextArea dataArea = new JTextArea();
	String s100 = "";
	/*-----------------------����װ��-----------------------*/
	private JTextField RFIDNumText_2;
	private JTextField AddressReText_2;
	private JTextField AddressSeText_2;
	private JTextField NumText_2;
	private JTextArea ScanDis_2;
	
	/*-----------------------����װ��-----------------------*/
	private JTextField RFIDNumText_3;
	private JTextField AddressReText_3;
	private JTextField AddressSeText_3;
	private JTextField NumText_3;
	private JTextField DriverText_3;
	private JTextArea ScanDis_3;
	
	/*-----------------------��������-----------------------*/
	private JTextField RFIDNumText_4;
	private JTextField AddressReText_4;
	private JTextField AddressSeText_4;
	private JTextField DriverText_4;
	private JTextField NumText_4;
	private JTextField DriverPhoneText_4;
	private JTextField TimeText1_4;
	private JTextField TimeText2_4;
	
	/*-----------------------���Ͱ���-----------------------*/
	private JTextField RFIDNumText_5;
	private JTextField OrderNumText_5;
	private JTextField NameReText_5;
	private JTextField PhoneReText_5;
	private JTextField AddressReText_5;
	private JTextField PsText_5;

	
	
	
	
	/**
	 * ִ��
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				JFrame.setDefaultLookAndFeelDecorated(true);
				JDialog.setDefaultLookAndFeelDecorated(true);
				try {
					UIManager.setLookAndFeel(new org.jvnet.substance.skin.SubstanceCremeLookAndFeel());//SubstanceCremeLookAndFeel  SubstanceNebulaLookAndFeel	
					mainWindow window = new mainWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
		//���캯��
		public mainWindow() {
			initialize();
		}
/*
		private byte[] getByteArray(String str) {
			str = str.replaceAll("[^0-9A-F]", "");
			byte[] ans = new byte[str.length() / 2];
			for (int i = 0; i < str.length(); i += 2) {
				ans[i / 2] = (byte) Integer.parseInt(str.substring(i, i + 2), 16);
			}
			return ans;
		}

		private void showData(JTextArea dataArea, byte[] data, String str, int pos,
				int len) {
			String dStr = "";
			for (int i = 0; i < len; i++) {
				dStr += String.format("%01x ", data[i + pos]);
			}
			dataArea.append(str + dStr.toUpperCase() + '\n');
		}

		private void showData(JTextArea dataArea, byte[] data, String str) {
			String dStr = "";
			for (byte b : data) {
				dStr += String.format("%01x ", b);
			}
			dataArea.append(str + dStr.toUpperCase() + '\n');
		}

		private void showStatue(JTextArea dataArea, byte Code) {
			int code = Code;
			if (code < 0)
				code += 256;
			showStatue(dataArea, code);
		}

		private void showStatue(JTextArea dataArea, int Code) {
			String msg = null;
			switch (Code) {
			case 0x00:
				msg = "Command succeed.....";
				break;
			case 0x01:
				msg = "Command failed.....";
				break;
			case 0x02:
				msg = "Checksum error.....";
				break;
			case 0x03:
				msg = "Not selected COM port.....";
				break;
			case 0x04:
				msg = "Reply time out.....";
				break;
			case 0x05:
				msg = "Check sequence error.....";
				break;
			case 0x07:
				msg = "Check sum error.....";
				break;
			case 0x0A:
				msg = "The parameter value out of range.....";
				break;
			case 0x80:
				msg = "Command OK.....";
				break;
			case 0x81:
				msg = "Command FAILURE.....";
				break;
			case 0x82:
				msg = "Reader reply time out error.....";
				break;
			case 0x83:
				msg = "The card does not exist.....";
				break;
			case 0x84:
				msg = "The data is error.....";
				break;
			case 0x85:
				msg = "Reader received unknown command.....";
				break;
			case 0x87:
				msg = "Error.....";
				break;
			case 0x89:
				msg = "The parameter of the command or the format of the command error.....";
				break;
			case 0x8A:
				msg = "Some error appear in the card InitVal process.....";
				break;
			case 0x8B:
				msg = "Get the wrong snr during anticollison loop.....";
				break;
			case 0x8C:
				msg = "The authentication failure.....";
				break;
			case 0x8F:
				msg = "Reader received unknown command.....";
				break;
			case 0x90:
				msg = "The card do not support this command.....";
				break;
			case 0x91:
				msg = "The foarmat of the command error.....";
				break;
			case 0x92:
				msg = "Do not support option mode.....";
				break;
			case 0x93:
				msg = "The block do not exist.....";
				break;
			case 0x94:
				msg = "The object have been locked.....";
				break;
			case 0x95:
				msg = "The lock operation do not success.....";
				break;
			case 0x96:
				msg = "The operation do not success.....";
				break;
			}
			msg += '\n';
			dataArea.append(msg);
		}
//		public void output(String s)
//		{
//			dataArea.setText(dataArea.getText()+s);
//		}
	*/	
		public void checkdata(String s)
		{
			String t0 = "";
			for ( int i = 0 ; i < s.length() ; i ++ )
			{
				char t1 = s.charAt(i);
				if ( (t1 >= '0' && t1 <='9') || (t1 >= 'A' && t1 <= 'Z') || (t1 >= 'a' && t1 <='z'))
				{
					t0 = t0 + t1;
				}
			}
			s100 = t0;
		}
		
		 /**
	     * ��ȡʡ��ֱϽ�У�������
	     */
	    public Object[] getProvince() {
	        Map<String, String[]> map = CityMap.model;// ��ȡʡ����Ϣ���浽Map��
	        Set<String> set = map.keySet(); // ��ȡMap�����еļ�������Set���Ϸ���
	        Object[] province = set.toArray(); // ת��Ϊ����
	        return province; // ���ػ�ȡ��ʡ����Ϣ
	    }

	    /**
	     * ��ȡָ��ʡ��Ӧ����/��
	     */
	    public String[] getCity(String selectProvince) {
	        Map<String, String[]> map = CityMap.model; // ��ȡʡ����Ϣ���浽Map��
	        String[] arrCity = map.get(selectProvince); // ��ȡָ������ֵ
	        return arrCity; // ���ػ�ȡ����/��
	    }

	    private void itemChange() {
	        String selectProvince = (String) comboBox.getSelectedItem();
	        cityComboBox.removeAllItems(); // �����/���б�
	        String[] arrCity = getCity(selectProvince); // ��ȡ��/��
	        cityComboBox.setModel(new DefaultComboBoxModel(arrCity)); // ����������/���б���ֵ
	    }
	    private void itemChange_1() {
	        String selectProvince = (String) comboBox_1.getSelectedItem();
	        cityComboBox_1.removeAllItems(); // �����/���б�
	        String[] arrCity = getCity(selectProvince); // ��ȡ��/��
	        cityComboBox_1.setModel(new DefaultComboBoxModel(arrCity)); // ����������/���б���ֵ
	    }
		/*====================================================================UI====================================================================*/
		/*-----------------------�Ŀ��-----------------------*/
		private void initialize(){
			frame = new JFrame("RFID�������������ϵͳ");
			frame.setBounds(460, 125, 1000, 750);
			 //�������������
			Toolkit t = Toolkit.getDefaultToolkit();
			//����ͼ������󣬲�ʹ�ù��������·����ȡͼƬ
			Image i = t.getImage("image/bg1.png");
			//���Ĵ����ͼ��
			frame.setIconImage(i);
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			frame.getContentPane().add(tabbedPane);
			frame.setResizable(false);	
			
			JPanel panel_1 = new JPanel() {
	            public void paintComponent(Graphics g) {
	                ImageIcon icon =new ImageIcon("image/bg_1.jpg");
	                float alpha = 0.3f; // ͸����   
	                Graphics2D g2d=(Graphics2D) g;
	                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_ATOP, alpha));
	                // ͼƬ�洰���С���仯
	                g2d.drawImage(icon.getImage(), 0, 0, frame.getSize().width,frame.getSize().height,frame);
	               
	            }
	        };
	        panel_1.setOpaque(false);
			tabbedPane.addTab("��������", null, panel_1, null);
			panel_1.setLayout(null);
			
			
			JLabel Title = new JLabel("��������");
			JLabel RFIDNumLabel = new JLabel("RFID�ţ�");
			JLabel OrderNumLabel=new JLabel("�˵��ţ�");
			JLabel RecipentLabel=new JLabel("��-----------------------��--------------------------��--------------------Ϣ"); 
			JLabel NameReLabel=new JLabel("�ռ���������");;
			JLabel PhoneReLabel=new JLabel("�ռ��˵绰��");
			JLabel AddressReLabel=new JLabel("�ռ��˵�ַ��");
			JLabel SendLabel=new JLabel("��-----------------------��--------------------------��--------------------Ϣ");
			JLabel NameSeLabel=new JLabel("�ļ���������");
			JLabel PhoneSeLabel=new JLabel("�ļ��˵绰��");
			JLabel AddressSeLabel=new JLabel("�ļ��˵�ַ��");
			JLabel PsLabel=new JLabel("��ע��Ϣ��");
			
			RFIDNumText = new JTextField(40);
			RFIDNumText.setEditable(false);
			OrderNumText=new JTextField(40);
			OrderNumText.setEditable(false);
			//RecipentText=new JTextField(40);
			NameReText=new JTextField(40);;
			PhoneReText=new JTextField(40);
		    AddressReText=new JTextField(40);
			//SendText=new JTextField(40);
			NameSeText=new JTextField(40);
			PhoneSeText=new JTextField(40);
			AddressSeText=new JTextField(40);
			PsText=new JTextField(40);
			
			JButton mfRead=new JButton("����");
			JButton Yes =new JButton("ȷ��");
			JButton No =new JButton("ȡ��");
			JButton Reset =new JButton("����");
			
			Font font=new Font("���Ĳ���",Font.BOLD,30);
			Title.setFont(font);
			Title.setForeground(Color.LIGHT_GRAY);
			Title.setBounds(445,25,140,30);
			panel_1.add(Title);
			RFIDNumLabel.setBounds(230,80,80,30);
			panel_1.add(RFIDNumLabel);
			RFIDNumText.setBounds(300,80,450,30);
			panel_1.add(RFIDNumText);
			OrderNumLabel.setBounds(234,130,80,30);
			panel_1.add(OrderNumLabel);
			OrderNumText.setBounds(300,130,450,30);
			panel_1.add(OrderNumText);
			mfRead.setBounds(460,170,100,40);
			panel_1.add(mfRead);
			RecipentLabel.setBounds(195,215,1000,20);
			RecipentLabel.setFont(new   java.awt.Font("Dialog",   1,   20));   
			RecipentLabel.setForeground(Color.white);
			panel_1.add(RecipentLabel);
			//panel.add(RecipentText);
			NameReLabel.setBounds(200, 245, 110, 30);
			panel_1.add(NameReLabel);
			NameReText.setBounds(300, 245, 450, 30);
			panel_1.add(NameReText);
			PhoneReLabel.setBounds(200,295,110,30);
			panel_1.add(PhoneReLabel);
			PhoneReText.setBounds(300,295,450,30);
			panel_1.add(PhoneReText);
			AddressReLabel.setBounds(200,345,110,30);
			panel_1.add(AddressReLabel);
			AddressReText.setBounds(630,345,120,30);
			panel_1.add(AddressReText);
					
			String province=(String)getProvince()[0];
			comboBox = new JComboBox();
			cityComboBox= new JComboBox();
			comboBox.setBounds(300,345, 100, 30);
	        panel_1.add(comboBox);
	        comboBox.addItemListener(new ItemListener() {
	            public void itemStateChanged(final ItemEvent e) { // ѡ��״̬�����¼�
	                itemChange();
	            }
	        });
	        comboBox.setModel(new DefaultComboBoxModel(getProvince())); // ����ʡ����Ϣ
	        
	        cityComboBox.setBounds(480, 345, 100, 30);
	        panel_1.add(cityComboBox); 
	        cityComboBox.setModel(new DefaultComboBoxModel(getCity(province)));
	        	        	        
	        final JLabel label = new JLabel();
	        label.setText("ʡ/ֱϽ��");
	        label.setBounds(400, 345, 80, 30);
	        panel_1.add(label);

	        final JLabel label_1 = new JLabel();
	        label_1.setText("��/��");
	        label_1.setBounds(580, 345, 50, 30);
	        panel_1.add(label_1);
	             
			SendLabel.setBounds(195,380,1000,20);
			SendLabel.setFont(new   java.awt.Font("Dialog",   1,   20));   
			SendLabel.setForeground(Color.white);
			panel_1.add(SendLabel);
			//panel.add(SendText);
			NameSeLabel.setBounds(200, 410, 110, 30);
			panel_1.add(NameSeLabel);
			NameSeText.setBounds(300, 410, 450, 30);
			panel_1.add(NameSeText);
			PhoneSeLabel.setBounds(200, 460, 110, 30);
			panel_1.add(PhoneSeLabel);
			PhoneSeText.setBounds(300, 460, 450, 30);
			panel_1.add(PhoneSeText);
			AddressSeLabel.setBounds(200, 510, 110, 30);
			panel_1.add(AddressSeLabel);
			AddressSeText.setBounds(630, 510, 120, 30);
			panel_1.add(AddressSeText);
			
			
			String province_1 = (String)getProvince()[0];
			comboBox_1 = new JComboBox();
			cityComboBox_1= new JComboBox();
			comboBox_1.setBounds(300,510, 100, 30);
	        panel_1.add(comboBox_1);
	        comboBox_1.addItemListener(new ItemListener() {
	            public void itemStateChanged(final ItemEvent e) { // ѡ��״̬�����¼�
	                itemChange_1();
	            }
	        });
	        comboBox_1.setModel(new DefaultComboBoxModel(getProvince())); // ����ʡ����Ϣ
			
	        cityComboBox_1.setBounds(480, 510, 100, 30);
	        panel_1.add(cityComboBox_1); 
	        cityComboBox_1.setModel(new DefaultComboBoxModel(getCity(province_1)));
	                
	        final JLabel label_2 = new JLabel();
	        label_2.setText("ʡ/ֱϽ��");
	        label_2.setBounds(400, 510, 80, 30);
	        panel_1.add(label_2);

	        final JLabel label_3 = new JLabel();
	        label_3.setText("��/��");
	        label_3.setBounds(580, 510, 50, 30);
	        panel_1.add(label_3);
			
			PsLabel.setBounds(218, 560, 100, 30);
			panel_1.add(PsLabel);
			PsText.setBounds(300, 560, 450, 30);
			panel_1.add(PsText);
			Yes.setBounds(380,610,100,40);
			panel_1.add(Yes);
			No.setBounds(580,610,100,40);
			panel_1.add(No);
			Reset.setBounds(900,610,80,40);
			panel_1.add(Reset);
			
			/*-------------------------����װ��-----------------------*/
			JPanel panel_2 = new JPanel(){
	            public void paintComponent(Graphics g) {
	                ImageIcon icon =new ImageIcon("image/bg_2.jpg");
	                float alpha = 0.3f; // ͸����   
	                Graphics2D g2d=(Graphics2D) g;
	                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_ATOP, alpha));
	                // ͼƬ�洰���С���仯
	                g2d.drawImage(icon.getImage(), 0, 0, frame.getSize().width,frame.getSize().height,frame);
	               
	            }
	        };
			tabbedPane.addTab("����װ��", null, panel_2, null);
			panel_2.setLayout(null);
			JLabel Title_2 = new JLabel("����װ��");
			JLabel RFIDNumLabel_2=new JLabel("RFID��(��)��");
			JLabel AddressReLabel_2=new JLabel("�����أ�");
			JLabel AddressSeLabel_2=new JLabel("Ŀ�ĵأ�");
			JLabel NumLabel_2=new JLabel("��������");
			JLabel RFIDLabel_2=new JLabel("����RFID�ţ�");
			JLabel ScanLabel_2=new JLabel("----------------------------------------ɨ----------------------------------------��----------------------------------------");
			RFIDNumText_2=new JTextField();
			RFIDNumText_2.setEditable(false);
			AddressReText_2=new JTextField();
			AddressSeText_2=new JTextField();
			NumText_2=new JTextField(40);
			NumText_2.setText("0");
			NumText_2.setEditable(false);
			ScanDis_2=new JTextArea();
			ScanDis_2.setEditable(false);
			JScrollPane ScanDisPane_2=new JScrollPane(ScanDis_2);
			ScanDisPane_2.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			//ScanDisPane.add(ScanDis);
			
			JButton mfRead_2=new JButton("����");
			JButton Yes_2=new JButton("ȷ��");
			JButton Scan_2=new JButton("ɨ��");
			JButton No_2=new JButton("ȡ��");
			JButton Reset_2=new JButton("����");
			
			Title_2.setFont(font);
			Title_2.setForeground(Color.LIGHT_GRAY);
			Title_2.setBounds(445,25,140,40);
			panel_2.add(Title_2);
			RFIDNumLabel_2.setBounds(170,80,110,40);
			panel_2.add(RFIDNumLabel_2);
			RFIDNumText_2.setBounds(300,80,400,40);
			panel_2.add(RFIDNumText_2);
			mfRead_2.setBounds(720, 80, 100, 40);
			panel_2.add(mfRead_2);
			AddressReLabel_2.setBounds(170, 140, 110, 40);
			panel_2.add(AddressReLabel_2);
			AddressReText_2.setBounds(300,140,520,40);
			panel_2.add(AddressReText_2);
			AddressSeLabel_2.setBounds(170,200,110,40);
			panel_2.add(AddressSeLabel_2);
			AddressSeText_2.setBounds(300,200,520,40);
			panel_2.add(AddressSeText_2);
			ScanLabel_2.setBounds(0,250,1000,25);
			panel_2.add(ScanLabel_2);
			NumLabel_2.setBounds(170,280,110,40);
			panel_2.add(NumLabel_2);
			NumText_2.setBounds(300,280,400,40);
			panel_2.add(NumText_2);
			Scan_2.setBounds(720,280,100,40);
			panel_2.add(Scan_2);
			RFIDLabel_2.setBounds(170,330,120,40);
			panel_2.add(RFIDLabel_2);
			ScanDisPane_2.setBounds(170,380,650,200);
			panel_2.add(ScanDisPane_2);
			Yes_2.setBounds(370,590,100,40);
			panel_2.add(Yes_2);
			No_2.setBounds(570,590,100,40);
			panel_2.add(No_2);
			Reset_2.setBounds(900,590,80,40);
			panel_2.add(Reset_2);
			
			/*-----------------------����װ��-----------------------*/
			JPanel panel_3 = new JPanel(){
	            public void paintComponent(Graphics g) {
	                ImageIcon icon =new ImageIcon("image/bg_3.jpg");
	                float alpha = 0.3f; // ͸����   
	                Graphics2D g2d=(Graphics2D) g;
	                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_ATOP, alpha));
	                // ͼƬ�洰���С���仯
	                g2d.drawImage(icon.getImage(), 0, 0, frame.getSize().width,frame.getSize().height,frame);
	               
	            }
	        };
			tabbedPane.addTab("����װ��", null, panel_3, null);
			panel_3.setLayout(null);
			JLabel Title_3 = new JLabel("����װ��");
			JLabel RFIDNumLabel_3=new JLabel("RFID��(��)��");
			JLabel AddressReLabel_3=new JLabel("�����أ�");
			JLabel AddressSeLabel_3=new JLabel("Ŀ�ĵأ�");
			JLabel NumLabel_3=new JLabel("��������");
			JLabel DriverLabel_3=new JLabel("��ʻԱ��");
			JLabel RFIDLabel_3=new JLabel("����RFID�ţ�");
			JLabel ScanLabel_3=new JLabel("----------------------------------------ɨ----------------------------------------��----------------------------------------");
			RFIDNumText_3=new JTextField();
			RFIDNumText_3.setEditable(false);
			AddressReText_3=new JTextField();
			AddressSeText_3=new JTextField();
			NumText_3=new JTextField(40);
			NumText_3.setText("0");
			NumText_3.setEditable(false);
			DriverText_3=new JTextField();
			ScanDis_3=new JTextArea();
			ScanDis_3.setEditable(false);
			JScrollPane ScanDisPane_3=new JScrollPane(ScanDis_3);
			ScanDisPane_3.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			//ScanDisPane.add(ScanDis);
			
			JButton mfRead_3=new JButton("����");
			JButton Yes_3=new JButton("ȷ��");
			JButton Scan_3=new JButton("ɨ��");
			JButton No_3=new JButton("ȡ��");
			JButton Reset_3=new JButton("����");
			
			Title_3.setFont(font);
			Title_3.setForeground(Color.LIGHT_GRAY);
			Title_3.setBounds(445,25,140,40);
			panel_3.add(Title_3);
			RFIDNumLabel_3.setBounds(170,80,110,40);
			panel_3.add(RFIDNumLabel_3);
			RFIDNumText_3.setBounds(300,80,180,40);
			panel_3.add(RFIDNumText_3);
			mfRead_3.setBounds(500, 80, 100, 40);
			panel_3.add(mfRead_3);
			DriverLabel_3.setBounds(630,80,110,40);
			panel_3.add(DriverLabel_3);
			DriverText_3.setBounds(700,80,120,40);
			panel_3.add(DriverText_3);
			AddressReLabel_3.setBounds(170, 140, 110, 40);
			panel_3.add(AddressReLabel_3);
			AddressReText_3.setBounds(300,140,520,40);
			panel_3.add(AddressReText_3);
			AddressSeLabel_3.setBounds(170,200,110,40);
			panel_3.add(AddressSeLabel_3);
			AddressSeText_3.setBounds(300,200,520,40);
			panel_3.add(AddressSeText_3);
			ScanLabel_3.setBounds(0,250,1000,25);
			panel_3.add(ScanLabel_3);
			NumLabel_3.setBounds(170,280,110,40);
			panel_3.add(NumLabel_3);
			NumText_3.setBounds(300,280,400,40);
			panel_3.add(NumText_3);
			Scan_3.setBounds(720,280,100,40);
			panel_3.add(Scan_3);
			RFIDLabel_3.setBounds(170,330,120,40);
			panel_3.add(RFIDLabel_3);
			ScanDisPane_3.setBounds(170,380,650,200);
			panel_3.add(ScanDisPane_3);
			Yes_3.setBounds(370,590,100,40);
			panel_3.add(Yes_3);
			No_3.setBounds(570,590,100,40);
			panel_3.add(No_3);
			Reset_3.setBounds(900,590,80,40);
			panel_3.add(Reset_3);
			
			/*-----------------------��������-----------------------*/
			JPanel panel_4 = new JPanel(){
	            public void paintComponent(Graphics g) {
	                ImageIcon icon =new ImageIcon("image/bg_4.jpg");
	                float alpha = 0.3f; // ͸����   
	                Graphics2D g2d=(Graphics2D) g;
	                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_ATOP, alpha));
	                // ͼƬ�洰���С���仯
	                g2d.drawImage(icon.getImage(), 0, 0, frame.getSize().width,frame.getSize().height,frame);
	               
	            }
	        };
			tabbedPane.addTab("��������", null, panel_4, null);
			panel_4.setLayout(null);
			JLabel Title_4 = new JLabel("��������");
			JLabel RFIDNumLabel_4=new JLabel("RFID��(��)��");
			JLabel AddressReLabel_4=new JLabel("Ŀ�ĵأ�");
			JLabel AddressSeLabel_4=new JLabel("�����أ�");
			JLabel NumLabel_4=new JLabel("��������");
			JLabel DriverLabel_4=new JLabel("��ʻԱ��");
			JLabel DriverPhoneLabel_4=new JLabel("��ʻԱ�绰��");
			JLabel TimeLabel_4=new JLabel("��ʼʱ�䣺");
			JLabel Timesignal_4=new JLabel("----");
			RFIDNumText_4=new JTextField();
			RFIDNumText_4.setEditable(false);
			AddressReText_4=new JTextField();
			AddressReText_4.setEditable(false);
			AddressSeText_4=new JTextField();
			AddressSeText_4.setEditable(false);
			NumText_4=new JTextField();
			NumText_4.setEditable(false);
			NumText_4.setText("");
			NumText_4.setEditable(false);
			DriverText_4=new JTextField();
			DriverText_4.setEditable(false);
			DriverPhoneText_4=new JTextField();
			DriverPhoneText_4.setEditable(false);
			TimeText1_4=new JTextField();
			TimeText1_4.setEditable(false);
			TimeText2_4=new JTextField();
			TimeText2_4.setEditable(false);
			
			JButton Yes_4=new JButton("��");
			JButton No_4=new JButton("ȡ��");
			JButton Reset_4=new JButton("����");
			
			Title_4.setFont(font);
			Title_4.setForeground(Color.LIGHT_GRAY);
			Title_4.setBounds(445,25,140,40);
			panel_4.add(Title_4);
			RFIDNumLabel_4.setBounds(170,80,110,40);
			panel_4.add(RFIDNumLabel_4);
			RFIDNumText_4.setBounds(300,80,520,40);
			panel_4.add(RFIDNumText_4);
			AddressReLabel_4.setBounds(170, 140, 110, 40);
			panel_4.add(AddressReLabel_4);
			AddressReText_4.setBounds(300,140,520,40);
			panel_4.add(AddressReText_4);
			AddressSeLabel_4.setBounds(170,200,110,40);
			panel_4.add(AddressSeLabel_4);
			AddressSeText_4.setBounds(300,200,520,40);
			panel_4.add(AddressSeText_4);
			NumLabel_4.setBounds(170,260,110,40);
			panel_4.add(NumLabel_4);
			NumText_4.setBounds(300,260,150,40);
			panel_4.add(NumText_4);
			DriverLabel_4.setBounds(170,320,110,40);
			panel_4.add(DriverLabel_4);
			DriverText_4.setBounds(300,320,150,40);
			panel_4.add(DriverText_4);
			DriverPhoneLabel_4.setBounds(170,380,110,40);
			panel_4.add(DriverPhoneLabel_4);
			DriverPhoneText_4.setBounds(300,380,520,40);
			panel_4.add(DriverPhoneText_4);
			TimeLabel_4.setBounds(170,440,110,40);
			panel_4.add(TimeLabel_4);
			TimeText1_4.setBounds(300,440,230,40);
			panel_4.add(TimeText1_4);
			Timesignal_4.setBounds(540,440,40,40);
			panel_4.add(Timesignal_4);
			TimeText2_4.setBounds(590,440,230,40);
			panel_4.add(TimeText2_4);
			
			Yes_4.setBounds(350,550,120,60);
			panel_4.add(Yes_4);
			No_4.setBounds(590,550,120,60);
			panel_4.add(No_4);
			Reset_4.setBounds(900,570,80,40);
			panel_4.add(Reset_4);
			
			/*-----------------------���Ͱ���-----------------------*/
			JPanel panel_5 = new JPanel(){
	            public void paintComponent(Graphics g) {
	                ImageIcon icon =new ImageIcon("image/bg_5.jpg");
	                float alpha = 0.3f; // ͸����   
	                Graphics2D g2d=(Graphics2D) g;
	                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_ATOP, alpha));
	                // ͼƬ�洰���С���仯
	                g2d.drawImage(icon.getImage(), 0, 0, frame.getSize().width,frame.getSize().height,frame);
	               
	            }
	        };
			tabbedPane.addTab("���Ͱ���", null, panel_5, null);
			panel_5.setLayout(null);
			JLabel Title_5 = new JLabel("���Ͱ���");
			JLabel RFIDNumLabel_5=new JLabel("RFID�ţ�");
			JLabel OrderNumLabel_5=new JLabel("�˵��ţ�");
			JLabel NameReLabel_5=new JLabel("������");;
			JLabel PhoneReLabel_5=new JLabel("�绰��");
			JLabel AddressReLabel_5=new JLabel("��ַ��");
			JLabel PsLabel_5=new JLabel("��ע��");
			JLabel RecipentLabel_5=new JLabel("-------------------------------------------------------------------�շ���Ϣ------------------------------------------------------------------"); 
			RFIDNumText_5=new JTextField();
			RFIDNumText_5.setEditable(false);
			OrderNumText_5=new JTextField();
			OrderNumText_5.setEditable(false);
			NameReText_5=new JTextField();
			NameReText_5.setEditable(false);
			PhoneReText_5=new JTextField();
			PhoneReText_5.setEditable(false);
			AddressReText_5=new JTextField();
			AddressReText_5.setEditable(false);
			PsText_5=new JTextField();
			PsText_5.setEditable(false);
						
			JButton mfRead_5=new JButton("����");
			JButton Yes_5=new JButton("���");
			JButton No_5=new JButton("ȡ��");
			JButton Reset_5=new JButton("����");
			
			Title_5.setFont(font);
			Title_5.setForeground(Color.LIGHT_GRAY);
			Title_5.setBounds(445,25,140,40);
			panel_5.add(Title_5);
			RFIDNumLabel_5.setBounds(170,80,110,40);
			panel_5.add(RFIDNumLabel_5);
			RFIDNumText_5.setBounds(300,80,520,40);
			panel_5.add(RFIDNumText_5);
			OrderNumLabel_5.setBounds(170, 140, 110, 40);
			panel_5.add(OrderNumLabel_5);
			OrderNumText_5.setBounds(300,140,520,40);
			panel_5.add(OrderNumText_5);
			mfRead_5.setBounds(460, 200, 100, 40);
			panel_5.add(mfRead_5);
			RecipentLabel_5.setBounds(0,250,1000,20);
			RecipentLabel_5.setFont(new   java.awt.Font("Dialog",   1,   20));   
			RecipentLabel_5.setForeground(Color.LIGHT_GRAY);
			panel_5.add(RecipentLabel_5);
			NameReLabel_5.setBounds(170,280, 110, 40);
			panel_5.add(NameReLabel_5);
			NameReText_5.setBounds(300, 280, 520, 40);
			panel_5.add(NameReText_5);
			PhoneReLabel_5.setBounds(170,340, 110, 40);
			panel_5.add(PhoneReLabel_5);
			PhoneReText_5.setBounds(300, 340, 520, 40);
			panel_5.add(PhoneReText_5);
			AddressReLabel_5.setBounds(170,400, 110, 40);
			panel_5.add(AddressReLabel_5);
			AddressReText_5.setBounds(300,400,520,40);
			panel_5.add(AddressReText_5);
			PsLabel_5.setBounds(170,460, 110, 40);
			panel_5.add(PsLabel_5);
			PsText_5.setBounds(300, 460, 520, 40);
			panel_5.add(PsText_5);
			Yes_5.setBounds(350,550,120,60);
			panel_5.add(Yes_5);
			No_5.setBounds(590,550,120,60);
			panel_5.add(No_5);
			Reset_5.setBounds(900,570,80,40);
			panel_5.add(Reset_5);
			
			
			frame.addComponentListener(new ComponentAdapter(){
			    public void componentResized(ComponentEvent e){
			       // �������ø�����Ĵ�С

			    }

			}); 
		    /*-----------------------�Ŀ��-----------------------*/
			// 14443A-MF
			mfRead.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					byte mode,t0,t1;
					mode=0x00;
					//add_blk��ʼ�飬num_blk������
					byte add_blk = (byte) Integer.parseInt((String)"10",16);
					byte num_blk = (byte) Integer.parseInt((String)"01",16);
					
					//t2��Կ
					String t2 = "FF FF FF FF FF FF";
					checkdata(t2);
					Pointer p = null ;
					try {
						p = new Pointer(MemoryBlockFactory.createMemoryBlock(6));
					} catch (NativeException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					for (int  i = 0 ; i < 6 ; i ++)
					{
						byte value = (byte)Integer.parseInt(s100.substring(2 * i , 2 * i + 2), 16);
						try {
							p.setByteAt(i, value);
						} catch (NativeException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					int ret = Function.MF_Read(mode, add_blk, num_blk, p);
					if(ret == 0)
					{
						String temp="";
						for ( int i = 0 ; i < 4 ; i ++)
						{
							try {
								temp=temp+String.format("%02X", Function.b.getAsByte(i));
							} catch (NativeException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
						}
						RFIDNumText.setText(temp);
						temp="";
						for ( int i = 0 ; i < 16*num_blk ; i ++)
						{
							try {
								temp=temp+String.format("%X", Function.a.getAsByte(i));
								//System.out.print(String.format("%X", Function.a.getAsByte(i))+" ");
							} catch (NativeException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						System.out.print("\n");
						OrderNumText.setText(temp);
					}
					else
					{
						RFIDNumText.setText("false ");
						Function.falsereason(Integer.toString(ret));
						RFIDNumText.setText(Function.reason);
						Function.falsereason(String.format("%X", Function.byte0));
						RFIDNumText.setText(Function.reason+"\n");
						Function.reason = "";
					}
				}

			});

			Yes.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					String re_p=(String)comboBox.getSelectedItem(); 
					String re_s=(String)cityComboBox.getSelectedItem();  
					String se_p=(String)comboBox_1.getSelectedItem(); 
					String se_s=(String)cityComboBox_1.getSelectedItem(); 
					System.out.println(re_p+re_s+AddressReText.getText()+'\n'+se_p+se_s+AddressSeText.getText());
					//�������ݿ�
					SendMessage sm = new SendMessage();
					sm.connectSQL();
					if(!RFIDNumText.getText().equals("")&&!OrderNumText.getText().equals("")&&!NameReText.getText().equals("")
							&&!PhoneReText.getText().equals("")&&!AddressReText.getText().equals("")&&!NameSeText.getText().equals("")
							&&!PhoneSeText.getText().equals("")&&!AddressSeText.getText().equals("")){
						sm.insertInfo_1(RFIDNumText.getText(),OrderNumText.getText()
								,NameReText.getText(),PhoneReText.getText(),re_p+re_s+AddressReText.getText()
								,NameSeText.getText(),PhoneSeText.getText(),se_p+se_s+AddressSeText.getText(),PsText.getText());
						sm.insertTransfer_1(RFIDNumText.getText(), OrderNumText.getText(), re_p+re_s+AddressReText.getText(),se_p+se_s+AddressSeText.getText());
					}
					else{
						RFIDNumText.setText("�뽫��Ҫ��Ϣ��д����");
					}
					sm.closeSQL();
					
					System.out.println(RFIDNumText.getText()+" "+OrderNumText.getText()
							+" "+NameReText.getText()+" "+PhoneReText.getText()+" "+AddressReText.getText()
							+" "+NameSeText.getText()+" "+PhoneSeText.getText()+" "+AddressSeText.getText()+" "+PsText.getText());
				}
			});
			
			No.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					System.exit(0);
				}
				
			});
			
			Reset.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					RFIDNumText.setText("");
					OrderNumText.setText("");
					NameReText.setText("");
					PhoneReText.setText("");
					AddressReText.setText("");
					NameSeText.setText("");
					PhoneSeText.setText("");
					AddressSeText.setText("");
					PsText.setText("");
				}
				
			});
			
			
			
			/*-----------------------����װ��-----------------------*/
			mfRead_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					byte mode,t0,t1;
					mode=0x00;
					byte add_blk = (byte) Integer.parseInt((String)"10",16);
					byte num_blk = (byte) Integer.parseInt((String)"01",16);
					
					String t2 = "FF FF FF FF FF FF";
					checkdata(t2);
					Pointer p = null ;
					try {
						p = new Pointer(MemoryBlockFactory.createMemoryBlock(6));
					} catch (NativeException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					for (int  i = 0 ; i < 6 ; i ++)
					{
						byte value = (byte)Integer.parseInt(s100.substring(2 * i , 2 * i + 2), 16);
						try {
							p.setByteAt(i, value);
						} catch (NativeException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					int ret = Function.MF_Read(mode, add_blk, num_blk, p);
					if(ret == 0)
					{
						String temp="";
						for ( int i = 0 ; i < 4 ; i ++)
						{
							try {
								temp=temp+String.format("%02X", Function.b.getAsByte(i));
							} catch (NativeException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
						}
						RFIDNumText_2.setText(temp);
					}
					else
					{
						RFIDNumText_2.setText("false ");
						Function.falsereason(Integer.toString(ret));
						RFIDNumText_2.setText(Function.reason);
						Function.falsereason(String.format("%X", Function.byte0));
						RFIDNumText_2.setText(Function.reason+"\n");
						Function.reason = "";
					}
				}

			});
			Scan_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					byte mode,t0,t1;
					mode=0x00;
					byte add_blk = (byte) Integer.parseInt((String)"10",16);
					byte num_blk = (byte) Integer.parseInt((String)"01",16);
					
					String t2 = "FF FF FF FF FF FF";
					checkdata(t2);
					Pointer p = null ;
					try {
						p = new Pointer(MemoryBlockFactory.createMemoryBlock(6));
					} catch (NativeException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					for (int  i = 0 ; i < 6 ; i ++)
					{
						byte value = (byte)Integer.parseInt(s100.substring(2 * i , 2 * i + 2), 16);
						try {
							p.setByteAt(i, value);
						} catch (NativeException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					int ret = Function.MF_Read(mode, add_blk, num_blk, p);
					if(ret == 0)
					{
						String temp="";String temp0="";
						for ( int i = 0 ; i < 4 ; i ++)
						{
							try {
								temp=temp+String.format("%02X", Function.b.getAsByte(i));
							} catch (NativeException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
						}
						ScanDis_2.setText(ScanDis_2.getText()+temp+"\n");
						
						int num=0;
						SendMessage sm = new SendMessage();
						sm.connectSQL();
						if(!RFIDNumText_2.getText().equals("")){
							sm.classification_2(temp,RFIDNumText_2.getText());
						}
						else{
							ScanDis_2.setText("����RFID�Ų���Ϊ��\n");
							num=Integer.valueOf(NumText_2.getText());
							num--;
							NumText_2.setText(String.valueOf(num));
						}
						sm.closeSQL();
						
						num=Integer.valueOf(NumText_2.getText());
						num++;
						NumText_2.setText(String.valueOf(num));
					}
					else
					{
						ScanDis_2.setText(ScanDis_2.getText()+"false ");
						Function.falsereason(Integer.toString(ret));
						ScanDis_2.setText(ScanDis_2.getText()+Function.reason);
						Function.falsereason(String.format("%02X", Function.byte0));
						ScanDis_2.setText(ScanDis_2.getText()+Function.reason+"\n");
						Function.reason = "";
					}
				}

			});
			Yes_2.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
					//�������ݿ�
					SendMessage sm = new SendMessage();
					sm.connectSQL();
					if(!RFIDNumText_2.getText().equals("")&&!AddressSeText_2.getText().equals("")&&!AddressReText_2.getText().equals("")
							&&!NumText_2.getText().equals("")){
						sm.insertInfo_2(RFIDNumText_2.getText(), AddressSeText_2.getText(), AddressReText_2.getText(), NumText_2.getText());
					}
					else{
						RFIDNumText_2.setText("�뽫��Ҫ��Ϣ��д����");
					}
					sm.closeSQL();
				}
			});
			
			No_2.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					System.exit(0);
				}
				
			});
			
			Reset_2.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					RFIDNumText_2.setText("");
					AddressSeText_2.setText("");
					AddressReText_2.setText("");
					NumText_2.setText("0");
					ScanDis_2.setText("");
				}
				
			});
			
			
			
			/*-----------------------����װ��-----------------------*/
			mfRead_3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					byte mode,t0,t1;
					mode=0x00;
					byte add_blk = (byte) Integer.parseInt((String)"10",16);
					byte num_blk = (byte) Integer.parseInt((String)"01",16);
					
					String t2 = "FF FF FF FF FF FF";
					checkdata(t2);
					Pointer p = null ;
					try {
						p = new Pointer(MemoryBlockFactory.createMemoryBlock(6));
					} catch (NativeException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					for (int  i = 0 ; i < 6 ; i ++)
					{
						byte value = (byte)Integer.parseInt(s100.substring(2 * i , 2 * i + 2), 16);
						try {
							p.setByteAt(i, value);
						} catch (NativeException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					int ret = Function.MF_Read(mode, add_blk, num_blk, p);
					if(ret == 0)
					{
						String temp="";
						for ( int i = 0 ; i < 4 ; i ++)
						{
							try {
								temp=temp+String.format("%02X", Function.b.getAsByte(i));
							} catch (NativeException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
						}
						RFIDNumText_3.setText(temp);
					}
					else
					{
						RFIDNumText_3.setText("false ");
						Function.falsereason(Integer.toString(ret));
						RFIDNumText_3.setText(Function.reason);
						Function.falsereason(String.format("%X", Function.byte0));
						RFIDNumText_3.setText(Function.reason+"\n");
						Function.reason = "";
					}
				}

			});
			Scan_3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					byte mode,t0,t1;
					mode=0x00;
					byte add_blk = (byte) Integer.parseInt((String)"10",16);
					byte num_blk = (byte) Integer.parseInt((String)"01",16);
					
					String t2 = "FF FF FF FF FF FF";
					checkdata(t2);
					Pointer p = null ;
					try {
						p = new Pointer(MemoryBlockFactory.createMemoryBlock(6));
					} catch (NativeException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					for (int  i = 0 ; i < 6 ; i ++)
					{
						byte value = (byte)Integer.parseInt(s100.substring(2 * i , 2 * i + 2), 16);
						try {
							p.setByteAt(i, value);
						} catch (NativeException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					int ret = Function.MF_Read(mode, add_blk, num_blk, p);
					if(ret == 0)
					{
						String temp="";
						for ( int i = 0 ; i < 4 ; i ++)
						{
							try {
								temp=temp+String.format("%02X", Function.b.getAsByte(i));
							} catch (NativeException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
						}
						ScanDis_3.setText(ScanDis_3.getText()+temp+"\n");
						
						int num=0;
						SendMessage sm = new SendMessage();
						sm.connectSQL();
						if(!RFIDNumText_3.getText().equals("")){
							sm.entrucking_3(temp,RFIDNumText_3.getText());
						}
						else{
							ScanDis_3.setText("����RFID�Ų���Ϊ��\n");
							num=Integer.valueOf(NumText_3.getText());
							num--;
							NumText_3.setText(String.valueOf(num));
						}
						sm.closeSQL();
						
						num=Integer.valueOf(NumText_3.getText());
						num++;
						NumText_3.setText(String.valueOf(num));
					}
					else
					{
						Function.falsereason(Integer.toString(ret));
						ScanDis_3.setText(ScanDis_3.getText()+Function.reason);
						Function.falsereason(String.format("%02X", Function.byte0));
						ScanDis_3.setText(ScanDis_3.getText()+Function.reason+"\n\n");
						Function.reason = "";
					}
				}

			});
			Yes_3.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
					//�������ݿ�
					SendMessage sm = new SendMessage();
					sm.connectSQL();
					if(!RFIDNumText_3.getText().equals("")&&!AddressSeText_3.getText().equals("")&&!AddressReText_3.getText().equals("")
							&&!NumText_3.getText().equals("")&&!DriverText_3.getText().equals("")){
						sm.insertInfo_3(RFIDNumText_3.getText(), AddressSeText_3.getText(), AddressReText_3.getText(), NumText_3.getText(),DriverText_3.getText());
					}
					else{
						RFIDNumText_3.setText("�뽫��Ҫ��Ϣ��д���");
					}
					sm.closeSQL();
				}
			});
			
			No_3.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					System.exit(0);
				}
				
			});
			
			Reset_3.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					RFIDNumText_3.setText("");
					AddressSeText_3.setText("");
					AddressReText_3.setText("");
					NumText_3.setText("0");
					DriverText_3.setText("");
					ScanDis_3.setText("");
				}
				
			});
			
			
			
			/*-----------------------��������-----------------------*/
			Yes_4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					byte mode,t0,t1;
					mode=0x00;
					byte add_blk = (byte) Integer.parseInt((String)"10",16);
					byte num_blk = (byte) Integer.parseInt((String)"01",16);
					
					String t2 = "FF FF FF FF FF FF";
					checkdata(t2);
					Pointer p = null ;
					try {
						p = new Pointer(MemoryBlockFactory.createMemoryBlock(6));
					} catch (NativeException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					for (int  i = 0 ; i < 6 ; i ++)
					{
						byte value = (byte)Integer.parseInt(s100.substring(2 * i , 2 * i + 2), 16);
						try {
							p.setByteAt(i, value);
						} catch (NativeException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					int ret = Function.MF_Read(mode, add_blk, num_blk, p);
					if(ret == 0)
					{
						String temp="";
						for ( int i = 0 ; i < 4 ; i ++)
						{
							try {
								temp=temp+String.format("%02X", Function.b.getAsByte(i));
							} catch (NativeException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
						}
						
						//UI��ʾ
						RFIDNumText_4.setText(temp);
						SendMessage sm = new SendMessage();
						sm.connectSQL();
						String str=sm.vehicleArrival_4(temp);
						String cut[]=null;
						while(str != null)	
						{
							cut=str.split(" ");
							break;
						}
						AddressSeText_4.setText(cut[1]);
						AddressReText_4.setText(cut[0]);
						NumText_4.setText(cut[2]);
						TimeText1_4.setText(cut[3]+" "+cut[4]);
						TimeText2_4.setText(cut[5]+" "+cut[6]);
						DriverText_4.setText(cut[7]);
						if(cut[8]!=null)
							DriverPhoneText_4.setText(cut[8]);	
						sm.closeSQL();

					}
					else
					{
						Function.falsereason(Integer.toString(ret));
						RFIDNumText_4.setText(Function.reason);
						Function.falsereason(String.format("%02X", Function.byte0));
						RFIDNumText_4.setText(Function.reason+"\n");
						Function.reason = "";
					}
				}

			});
			
			No_4.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					System.exit(0);
				}
				
			});
			
			Reset_4.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					RFIDNumText_4.setText("");
					AddressSeText_4.setText("");
					AddressReText_4.setText("");
					NumText_4.setText("");
					TimeText2_4.setText("");
					TimeText1_4.setText("");
					DriverText_4.setText("");
					DriverPhoneText_4.setText("");
				}
				
			});
			
			
			
		    /*-----------------------���Ͱ���-----------------------*/
			mfRead_5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					byte mode,t0,t1;
					mode=0x00;
					byte add_blk = (byte) Integer.parseInt((String)"10",16);
					byte num_blk = (byte) Integer.parseInt((String)"01",16);
					
					String t2 = "FF FF FF FF FF FF";
					checkdata(t2);
					Pointer p = null ;
					try {
						p = new Pointer(MemoryBlockFactory.createMemoryBlock(6));
					} catch (NativeException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					for (int  i = 0 ; i < 6 ; i ++)
					{
						byte value = (byte)Integer.parseInt(s100.substring(2 * i , 2 * i + 2), 16);
						try {
							p.setByteAt(i, value);
						} catch (NativeException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					int ret = Function.MF_Read(mode, add_blk, num_blk, p);
					if(ret == 0)
					{
						String temp="";
						for ( int i = 0 ; i < 4 ; i ++)
						{
							try {
								temp=temp+String.format("%02X", Function.b.getAsByte(i));
							} catch (NativeException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
						}
						RFIDNumText_5.setText(temp);
						temp="";
						for ( int i = 0 ; i < 16*num_blk ; i ++)
						{
							try {
								temp=temp+String.format("%X", Function.a.getAsByte(i));
							} catch (NativeException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						System.out.print("\n");
						OrderNumText_5.setText(temp);
						//UI��ʾ
						SendMessage sm = new SendMessage();
						sm.connectSQL();
						String str=sm.sendExpressDelivery_5(RFIDNumText_5.getText());
						String cut[]=null;
						if(str != null)	
						{
							cut=str.split(" ");
						}
						
						NameReText_5.setText(cut[0]);
						PhoneReText_5.setText(cut[1]);
						AddressReText_5.setText(cut[2]);
						if(cut.length>3)
							PsText_5.setText(cut[3]);
						sm.closeSQL();
						
					}
					else
					{
						Function.falsereason(Integer.toString(ret));
						Function.falsereason(String.format("%02X", Function.byte0));
						RFIDNumText.setText(Function.reason+"\n");
						Function.reason = "";
					}
				}

			});

			Yes_5.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
					//�������ݿ�
					SendMessage sm = new SendMessage();
					sm.connectSQL();
					sm.finishSendExpressDelivery_5(RFIDNumText_5.getText(),AddressReText_5.getText());
					sm.closeSQL();
				}
			});
			
			No_5.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					System.exit(0);
				}
				
			});
			
			Reset_5.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					RFIDNumText_5.setText("");
					OrderNumText_5.setText("");
					NameReText_5.setText("");
					PhoneReText_5.setText("");
					AddressReText_5.setText("");
					PsText_5.setText("");
				}
				
			});
		}
}

package sendInfo;

//以下三行为导入连接数据库需要用的驱动包，异常包
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class SendMessage {
	
	//以下注释的部分根据自己建立的数据库情况修改，其他部分不用改
	protected static String dbClassName = "com.mysql.jdbc.Driver";
	//protected static String dbUrl = "jdbc:mysql://localhost/rfid?useUnicode=true&characterEncoding=utf8";//连接数据库的连接，安装在本机的话，IP地址可以为127.0.0.0，也可以直接用主机名localhost
	protected static String dbUser = "root";//连接数据库的用户名
	protected static String dbUrl = "jdbc:mysql://111.231.221.144/rfid?useUnicode=true&characterEncoding=utf8";//杩炴帴鏁版嵁搴撶殑杩炴帴锛屽畨瑁呭湪鏈満鐨勮瘽锛孖P鍦板潃鍙互涓�27.0.0.0锛屼篃鍙互鐩存帴鐢ㄤ富鏈哄悕localhost
	protected static String dbPwd = "";//连接数据库的密码
	//protected static String dbPwd = "root";////连接数据库的密码
	protected static String second = null;
	private static Connection conn = null;
	protected static ResultSet rs = null;
	
	//连接数据库
	public void connectSQL(){
		if(conn == null) {
			try {
				Class.forName(dbClassName).newInstance();
				conn = DriverManager.getConnection(dbUrl, dbUser, dbPwd);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	//关闭连接，直接用
	public void closeSQL(){
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("conn close failed.");
		}
		conn = null;
	}
	
	//执行数据库查询
	private ResultSet excuteResult(String sql){
		if(conn == null){
			this.connectSQL();
		}
		try {
			return (ResultSet) conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE).executeQuery(sql);
		} catch (SQLException e) {
			return null;
		}
	}
	//执行数据库插入
	public int excuteUpdate(String sql){
		try {
			if(conn == null){
				this.connectSQL();
			}
			return conn.createStatement().executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Update sql failed..");
		}
		return -1;
	}
		
	
/*------------- 以上是 数据库 基本操作部分        --------------------*/
	
	/*
	 * 将数据插入到数据表 package_information
	 * */
	public void insertInfo_1(String RFID,String OrderNum,String RecipientName,String RecipientPhone
			,String RecipientAddress,String SendName,String SendPhone,String SendAddress,String Ps) {
		String sql = "insert into package_information(RFID,OrderNum,RecipientName,RecipientPhone,RecipientAddress,"
				+ "SendName,SendPhone,SendAddress,Remarks) " + "values('"+RFID+"','"+OrderNum+"',"
				+ "'"+RecipientName+"','"+RecipientPhone+"','"+RecipientAddress+"',"
				+ "'"+SendName+"','"+SendPhone+"','"+SendAddress+"','"+Ps+"')";
		this.excuteUpdate( sql );
		
	}
	
	
	/*
	 * 将数据插入到数据表transfer
	 * */
	public void insertTransfer_1(String RFID,String OrderNum,String RecipientAddress,String SendAddress) {
		String sql = "insert into transfer(RFID,OrderNum,RecipientAddress,SendAddress) " 
	+ "values('"+RFID+"','"+OrderNum+"','"+RecipientAddress+"','"+SendAddress+"')";
		this.excuteUpdate( sql );
		
	}
	
	
	/*
	 * 将数据插入到数据表 package_classification
	 * */
	public void insertInfo_2(String RFID,String DesAddress,String StartAddress,String Num) {
		String sql = "insert into package_classification(RFID,DesAddress,StartAddress,Num) " + "values('"+RFID+"','"+DesAddress+"',"
			+ "'"+StartAddress+"','"+Num+"')";
		this.excuteUpdate( sql );
			
	}
	
	
	/*
	 * 将数据插入到数据表 package_entrucking
	 * */
	public void insertInfo_3(String RFID,String DesAddress,String StartAddress,String Num,String Driver) {
		String sql1 = "select * from driver_information where name='"+Driver+"'";
		rs=this.excuteResult( sql1 );
		String DriverPhone="";
		try {
			while(rs.next()){
				DriverPhone=rs.getString("driverPhone");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	
		String sql2 = "insert into package_entrucking(RFID,DesAddress,StartAddress,Num,Driver,DriverPhone) " + "values('"+RFID+"','"+DesAddress+"',"
			+ "'"+StartAddress+"','"+Num+ "','"+Driver+"','"+DriverPhone+"')";
		this.excuteUpdate( sql2 );
			
	}
	
	
	/*
	 * 更新package_information中包裹GroupNum装箱号
	 * */
	public void classification_2(String RFID,String GroupNum){

		String sql="UPDATE package_information SET GroupNum='"+GroupNum+"' WHERE RFID = '"+RFID+"'"; 
	//	System.out.println(sql);
		this.excuteUpdate( sql );  
	}
	
	
	/*
	 * 更新package_information中包裹CarNum装车号
	 * */
	public void entrucking_3(String RFID,String CarNum){

		String sql = "SELECT * FROM package_information WHERE GroupNum = '"+RFID+"'";
		rs = this.excuteResult( sql );
		try {
			while(rs.next())
			{
				String rfid=rs.getString("RFID");
				String orderNum=rs.getString("OrderNum");			
				System.out.println(rfid+" "+orderNum);
				String sql2="UPDATE package_information SET CarNum='"+CarNum+"' WHERE RFID = '"+rfid+"'"; 
				//	System.out.println(sql);
				this.excuteUpdate(sql2); 
			}
		} catch (SQLException e) {
			System.out.println("Sql execute failed 1");
		
		}
		String sql3="UPDATE package_classification SET 	InTheCar='"+CarNum+"' WHERE RFID = '"+RFID+"'"; 
		this.excuteUpdate(sql3); 
	}
	
	
	/*
	 * 更新package_entrucking中车辆的到达时间和状态，
	 * 将车辆到达的目的地加入transfer表，
	 * 更新package_classification中的到达时间，
	 * 更新package_information的CarNum
	 * */
	public String vehicleArrival_4(String RFID){

		String sql = "SELECT * FROM package_entrucking WHERE RFID = '"+RFID+"'";
		rs = this.excuteResult( sql );
		String temp=null;
		String desAddress=null;
		Date date=new Date();     //获取一个Date对象
		DateFormat simpleDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");   //创建一个格式化日期对象
		String punchTime = simpleDateFormat.format(date);   //格式化后的时间
		try {
			while(rs.next())
			{
				desAddress=rs.getString("DesAddress");
				String startAddress=rs.getString("StartAddress");
				String num=rs.getString("Num");
				String RecipientTime=rs.getString("RecipientTime");
				String ArriveTime=punchTime;
				String Driver=rs.getString("Driver");
				String DriverPhone=rs.getString("DriverPhone");
				
			    temp=desAddress+" "+startAddress+" "+num+" "+RecipientTime+" "+ArriveTime+" "+Driver+" "+DriverPhone;
				System.out.println(temp);
				
			}
		} catch (SQLException e) {
			System.out.println("Sql execute failed 2");
		}
		//设置车辆运输状态state=1 表示到达  更新到达时间
		String sql2="UPDATE package_entrucking SET state=1,ArriveTime='"+punchTime+"' WHERE RFID = '"+RFID+"'"; 
		this.excuteUpdate( sql2 ); 
			
		//将车辆到达的目的地加入transfer表
		String sql3="SELECT RFID,RecipientAddress FROM package_information WHERE CarNum = '"+RFID+"'";
		rs = this.excuteResult( sql3 );
		try {
			while(rs.next())
			{
				String rfid=rs.getString("RFID");
				String recipientAddress=rs.getString("RecipientAddress");
				String place="TransAddress"+findNullPlace(rfid);
				String transTime="TransTime"+findNullPlace(rfid);
				System.out.println(recipientAddress+" "+desAddress);
				//if(recipientAddress.equals(desAddress)){
				//	String sql4="UPDATE transfer SET state=1,"+place+"='"+desAddress+"',"+transTime+"='"+punchTime+"' WHERE RFID = '"+rfid+"'"; 
				//	this.excuteUpdate( sql4 ); 
				//}
				//else{
				String sql4="UPDATE transfer SET "+place+"='"+desAddress+"',"+transTime+"='"+punchTime+"' WHERE RFID = '"+rfid+"'"; 
				this.excuteUpdate( sql4 ); 
				//}		
				System.out.println(rfid+" ");
			}
		} catch (SQLException e) {
			System.out.println("Sql execute failed 3");
		}
		
		//更新package_classification中的到达时间
		String sql4="UPDATE package_classification SET State=1,ArriveTime='"+punchTime+"' WHERE InTheCar = '"+RFID+"'"; 
		this.excuteUpdate( sql4 ); 
		
		//更新package_information的CarNum
		String sql5="UPDATE package_information SET CarNum='' WHERE CarNum = '"+RFID+"'"; 
		this.excuteUpdate( sql5 ); 
		return temp;
	}
	
	
	public String findNullPlace(String rfid){
		String place=null;
		String sql="SELECT * FROM transfer WHERE RFID = '"+rfid+"'";
		ResultSet rs = this.excuteResult( sql );
		try {
			while(rs.next())
			{
				String temp="TransAddress";
				for(int i=1;i<=15;i++){
					place=rs.getString(temp+Integer.toString(i));
					if(place==null){
						return (Integer.toString(i));
					}
				}				
			}
		} catch (SQLException e) {
			System.out.println("Sql execute failed 4");
		}
		return place;
	}
	
	/*
	 * 找到该RFID号包裹的相关信息并返回
	 * */
	public String sendExpressDelivery_5(String RFID){
		String str=null;
		String sql="SELECT * FROM package_information WHERE RFID = '"+RFID+"'";
		ResultSet rs = this.excuteResult( sql );
		try {
			while(rs.next())
			{
				String recipientName=rs.getString("RecipientName");
				String recipientPhone=rs.getString("RecipientPhone");
				String recipientAddress=rs.getString("RecipientAddress");
				String remarks=rs.getString("Remarks");	
				str=recipientName+" "+recipientPhone+" "+recipientAddress+" "+remarks;
			}
		} catch (SQLException e) {
			System.out.println("Sql execute failed 5");
		}
	
		return str;
	}
	
	
	/*
	 * 更新package_information表中的状态和到达时间
	 * 更新transfer表中的状态和最后物流信息
	 * */
	public void finishSendExpressDelivery_5(String RFID,String recipientAddress){
		Date date=new Date();     //获取一个Date对象
		DateFormat simpleDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");   //创建一个格式化日期对象
		String punchTime = simpleDateFormat.format(date);   //格式化后的时间
		
		//更新package_information表中的状态和到达时间
		String sql="UPDATE package_information SET State=1,ArriveTime='"+punchTime+"' WHERE RFID = '"+RFID+"'"; 
		this.excuteUpdate( sql ); 
		
		//更新transfer表中的状态和最后物流信息
		String place="TransAddress"+findNullPlace(RFID);
		String transTime="TransTime"+findNullPlace(RFID);
		String sql2="UPDATE transfer SET state=1,"+place+"='"+recipientAddress+"已签收',"+transTime+"='"+punchTime+"' WHERE RFID = '"+RFID+"'"; 
		this.excuteUpdate( sql2 ); 
		 
	}
}

#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

void LED_Init(void);//��ʼ��
#define LED     PAout(0)
#define PWRKEY  PAout(5)
#endif
